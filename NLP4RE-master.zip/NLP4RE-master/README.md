# NLP4RE
The python code for to identify Elements from requirements sentence at a time.
The code is located in spaCy\nlp4re folder.

## Folder Structure
 * ```nlp4re\handler ``` contains how to process requirement(a sentence) for each types of requirement.
 	*  ``` requirement_handler.py ```  is a abstract parent class of each types for handler.
 	*  ``` environment_handler.py ```  is a class for processing the environment requirements.
 	*  ``` suitability_handler.py ```  is a class for processing the suitability requirements.
 	*  ``` design_handler.py ```  is a class for processing the design requirement. 
 * ```nlp4re\parser ```  contains parser for elements/elementgroups.
 * ```nlp4re\elements``` contains elements to be identified during parsing.
 	*  ``` element.py ```  contains Element class that is abstract class for all elements, its subclass SingleOrGroupElement, SingleElement, ElementGroup and ConjElement.  Also contains Confidence class for defining the its type in Enumeration.
	*  ``` article.py ```  contains Article class to epresent Agent's article (The, Any, Each).
	*  ``` agnet.py ```  contains Agent class to represent Agent.
 	*  ``` agent_conj.py ```  contains AgentConj class to represent when more than one ArticleAgents is found a sentence related with a conj("and").
 	*  ``` article_agnet.py ```  contains ArticleAgent class that is subclass for ElementGroup.  The class groups Article and Agent together.
 	
	*  ``` boundary.py ```  contains Boundary class to represent Boundary.
	*  ``` value.py ```  contains Value class to epresent Value.
 	*  ``` boundary_value_conj.py ```  contains BoundaryValueConj class to represent when more than one BoundaryValues is found a sentence related with a conj("and").
 	*  ``` boundary_value.py ```  contains BoundaryValue class that is subclass for ElementGroup.  The class groups Boundary and Value together.

	*  ``` section.py ```  contains Section class to represent Section.
	*  ``` resource.py ```  contains Resource class to epresent Resource.
 	*  ``` setion_resource_conj.py ```  contains SectionResourceConj class to represent when more than one SectionResources is found a sentence related with a conj("and").
 	*  ``` boundary_value.py ```  contains BoundaryValue class that is subclass for ElementGroup.  The class groups Boundary and Value together.
 	
 	*  ``` characteristic.py ```  contains Characteristic class to represent Characteristic.
 	*  ``` condition_event.py ```  contains ConditionEvent class to represent Condition or Event (created for environment requirement parsing).  
	*  ``` state.py ```  contains State class to represent State.
	*  ``` when.py ```  contains When class to represent during, after, or during and after.

## Execution

### Local/Direct Execution

To run Enviroment requirement extraction per line, run Environment_Handler in spaCy\nlp4re\handler\environment_handler.py
The main contains example codes.

```
h = Environment_Handler() or SuitabilityHandler() or DesignHandler()
h.process_line('requirement sentence.')

#for elements
elements = h.getElements()

#for tokens
doc = h.getDoc()
for t in doc:
	print(t.text, t.i) #token text, token index

================ sample code =====================
elements = esw.getElements()
print(f"element:{Requirement_Handler.elements2str(elements)}")
print("==details===")
for e in esw.getElements():
	if issubclass(type(e), SingleElement):
		print( e.__class__.__name__, e.getTexts(), e.getConfidenceValue(), e.getConfidenceNames(), e.getFit())
	elif isinstance(e, ElementGroup):
		print(  e.__class__.__name__, e.getTexts(), e.getConfidenceValue(), e.getFit())
	for key, value in e.getElements().items(): #getElements = Dictionary
		#print(key, values)
		if value != None:
			if isinstance(value, SingleElement):#SectionResource, BoundaryValue
			   print( "\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(), value.getConfidenceNames(), value.getFit())     
  else: #ConjElements
	print( e.__class__.__name__, e.getTexts(), e.getConfidenceValue())
	for value in e.getElements():
		if isinstance(value, SingleElement): #with Agent
			print( "\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(), value.getConfidenceNames(), value.getFit()) 
		else: #ConjElement with SectionResource, BoundaryValue  
			print( "\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(), value.getFit())   
			for key2, value2 in value.getElements().items(): #getElements = Dictionary
				if isinstance(value2, SingleElement): 
					print( "\t\t", value2.__class__.__name__, value2.getTexts(), value2.getConfidenceValue(), value2.getConfidenceNames(), value2.getFit()) 
# for tokens
for t in esw.getDoc():
	print(t.text, t.i)
======================================================
``` 


```
Data Class structure
===============
abstract Element (list(String):getTexts(), float: getConfidenceValue(), list(tokens): getTokens())
|--- abstract ConjElements (list[TokenSpan]: getConj(), list(Element): getElements(), boolean: getExpand())
	|--- AgentsConj (list(Agents): *getElements())
	|--- SectionResourcesConj (list(SectionResrouce)): *getElements())
	|--- BoundaryValueConj (list(BoundaryValue)): *getElements())
|--- abstarct SingleOrGroupElement  (boolean: getFit())
	|--- SingleElement (list(Confidences): getConficences(), void: setTexts(), void setConfidenceValue(), void addConfidences(c))
		|--- Agent
		|--- ConditionEvent
		|--- State
		|--- Section
		|---Resource
		|---Boundary
		|---Value
		|---Characteristic
		|---MatchElement
			|--- When
	|--- ElementGroup (Dict(key= class, value= SingleElement ): getElements())
		|--- SectionResource (Dict(key = Section or Resource class, value = None, or an instance of the key class))
		|--- BoundaryValue (Dict(key = Boundary or Value class, value = None or an instance of the key class))
		|--- ArticleAgent (Dict(key = Article or Agent class, value = an instance of the key class))
		
```
### Docker

The corresponding docker image (not included within the repo) is named according to the release level of the code it was built from and may be loaded and executed directly.