from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence

@dataclass
class Agent(SingleElement):
    """ Data class for Agent element
    Args:
        SingleElement : this class's superclass
    """
    #confidence options for Agent
    confidence_options = {
            Confidence.Term.name: 1.0,
            Confidence.DEP_NsubjNsubjpass_ROOT.name: 0.9,
            Confidence.DEP_NsubjNsubjpass.name :0.5,
            Confidence.Similar.name : 0.4,
            Confidence.Agent_of.name : 0.6,
        }

    def __init__(self, tokens, confidences, fit=True, texts=None):
        """initialization - use superclass constructor"""
        super().__init__(tokens, confidences, fit=fit, texts=texts)

    def setTexts(self):
        """Setting texts for this element.  If it is identified from Confidence.Term, then its texts will not converted into singular form.
        Otherwise, its texts will be converted into singular form.
        """
        if Confidence.Term in self.getConfidences():
            self._texts.append(self.toTitleCase_Agent(False))
        else:
            self._texts.append(self.toTitleCase_Agent())

    def setConfidenceValue(self):
        """Setting confidence value.
        If this element is created without tokens, then set its Confidence value as 0.
        Otherwise calculated based on its confidences.
        """
        if self._tokens == None:
            self._confidenceValue = 0
        else:
            self._confidenceValue = SingleElement.calculateConfidenceValue(Agent.confidence_options, self._confidences)
       