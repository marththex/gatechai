from dataclasses import dataclass
from nlp4re.elements.element import ConjElements


@dataclass
class AgentsConj(ConjElements):
    """
    Data class of list of Agent elements connected by 'and' or 'or'
    self._expand = True because Mutiple Agents should create multiple requirements

    For example, Agents extracted are  'AAA', 'BBB', 'CCC' from the original text 'AAA, BBB, and CCC',
    self._conj = "and" or "or" token
    self._conj_elements = [Agent(text = 'AAA'), Agent(text = 'BBB'), Agent(text = 'CCC'), Agent(text = 'AAA, BBB, and CCC')]
    self._expand = True
    """

    _expand: bool = True
   