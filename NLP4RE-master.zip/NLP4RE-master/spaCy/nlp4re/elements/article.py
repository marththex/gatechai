from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence
from enum import Enum

@dataclass(frozen=True)  # The "frozen" parameter makes the class immutable
class Enum_Article(Enum):
    """Enumeration for Article

    Args:
        Enum (Class): super class for this class
    """
    The = 1
    Any = 2
    Each = 3

    def __str__(self):
        """return Enumeration in text (ie., "The") """
        return self.name


@dataclass
class Article(SingleElement):
    """
     if agent_plural:
            return Agent_DET_ANY_EACH()
        elif agent_det == None or agent_det.lower() == "the":
            return Agent_DET_THE()
        else:  # Each or Any
            return Agent_DET_ANY_EACH()

    Args:
        SingleElement (Class): super class for this element
    """

    def __init__(self, tokens, enum_dets=None):
        """ Since it is possible tokens does not match what text should be ("All" token to "Each/Any"), its text is created from Article enumeration and pass to superclass constructor.
        Confidence of Article is alwas Confidence.Match
        Args:
            tokens (list of Tokens): tokens represent Article o Agent
            texts (list[Enum_DET], optional): _description_. Defaults is None.
        """
        temp = []
        for ed in enum_dets:
            temp.append(ed.name)
        super().__init__(tokens, [Confidence.Match], fit=True, texts=temp)

    def setTexts(self):
        """set its text only if its texts is not set.
        """
        if len(self._texts) == 0:
            self._texts.append(self._tokens.text)

    def setConfidenceValue(self):
        """The Article confidence is always Confidence.Match.  So simply set as 1.0 here.
        """
        self._confidenceValue = 1.0 # Confidence.Match
