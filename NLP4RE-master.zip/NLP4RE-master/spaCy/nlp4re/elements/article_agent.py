from dataclasses import dataclass
from nlp4re.elements.element import ElementGroup
from nlp4re.elements.agent import Agent
from nlp4re.elements.article import Article 



@dataclass
class ArticleAgent(ElementGroup):
    """ Data class for Agent element
        Subclass for SingleElement
    """
    
    def __init__(self, d, a):
        """initialization - use superclass constructor"""
        super().__init__(Article, d, Agent, a)

    def setTexts(self):
        """set text of self._texts"""
        for d in self._elements[Article].getTexts():
            for a in self._elements[Agent].getTexts():
                self._texts.append(d + " " + a)

    def getFirstIndex(self):
        """return the token index of this element in parsed text.  
        For example, "dog" token index of "I love dogs" is 2. 

        Returns:
            int: index of this element in parsed text.
        """
        if self._elements[Article].getTokens() != None:
            return self._elements[Article].getTokens().i
        else:
            return self._elements[Agent].getTokens()[0].i 

    def getTextsWithUnfit(self):
        """info method to put** of Section or Resource is unfit words"""
        return self._elements[Article].getTextsWithUnfit() + self._elements[Agent].getTextsWithUnfit()