from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence


@dataclass
class Boundary(SingleElement):
    """ Data class for Boundary element
    Args:
        SingleElement : this class's superclass
    """
    #confidence options for this element
    confidence_options = {
            Confidence.Term.name: 1.0,
            Confidence.Term_Unit.name: 1.0,
        }

    def __init__(self, tokens, confidences, texts=None):
        """initialization - use superclass constructor"""
        super().__init__(
            tokens, confidences, texts=texts
        )  
    def setTexts(self):
        """Setting texts for this element. """
        self._texts.append(self._tokens.text)

    def setConfidenceValue(self):
        """Setting confidence value.
        If this element is created without tokens, then set its Confidence value as 0.
        Otherwise calculated based on its confidences.
        """
        if self._tokens == None:
            self._confidenceValue = 0
        else:
            self._confidenceValue = SingleElement.calculateConfidenceValue(Boundary.confidence_options, self._confidences)

   

