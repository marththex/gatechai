from dataclasses import dataclass
from nlp4re.elements.element import ElementGroup
from nlp4re.elements.boundary import Boundary
from nlp4re.elements.value import Value


@dataclass
class BoundaryValue(ElementGroup):
    """
    This is a data class for an boundled boundary and value.
    For example, for "less than 3.1 kg".  Boundary is "less than" and value is "3.1 kg".
    """

    # _elements = {Boundary: _bounday, _value: Value}
    def __init__(self, b, v):
        """
        The constructor for Bounday Value class

        Parameters:
           b (Bounday): The Boundary object.
           v (Value): The Value object.
        """
        super().__init__(Boundary, b, Value, v)

    def setTexts(self):
        """set text of self._texts"""
        # assert (
        #     self._elements[Boundary] == None
        #     or len(self._elements[Boundary].getTexts()) == 1
        # )
        assert (
            self._elements[Value] == None or len(self._elements[Value].getTexts()) == 1
        )
        s = (
            self._elements[Boundary].getTexts()[0] + " "
            if self._elements[Boundary] != None
            else ""
        )
        s += (
            self._elements[Value].getTexts()[0] if self._elements[Value] != None else ""
        )
        self._texts = [s.strip()]

    def get_boundary_index(self):
        boundary = self._elements[Boundary]
        return (
            [boundary.getTokens().start, boundary.getTokens().end]
            if boundary is not None
            else [None, None]
        )

    def get_value_index(self):
        value = self._elements[Value]
        return [value.getTokens().start, value.getTokens().end]

    def getTextsWithUnfit(self):
        """info method to put** of Section or Resource is unfit words"""
        return self._elements[Boundary].getTextsWithUnfit() + self._elements[Value].getTextsWithUnfit()