from dataclasses import dataclass
from nlp4re.elements.element import ConjElements


@dataclass
class BoundaryValueConj(ConjElements):
    """
    Data class of list of BoundaryValue elements connected by 'and'
    #"""

    # def __init__(self, cj, es, expand=False):
    #     """constructor for this data class

    #     Args:
    #         cj (token): "and" or "or" token connecting list of BoundaryValue elements
    #         es (list of BoundaryValue): list of BoundaryValue elements
    #     """
    #     super().__init__(conj = cj, elements = es, expand= expand)
    _expand: bool = False

   
    # "between" will not be in Term Definition
    #     text = "... from 1 to 10 and/or between 2 and  20"
    # from NER.QUANTITY create BV1 and BV2
    #     BV1 = 1 NER.QUANTITY (BV(B=between, V 1))
    #     BV2 = 10 NER.QUANTITY (BV(B=and, V 10))
    #     then combined to
    #     BVC( ["between", "and"], [BV1, BV2])

    #     BVC (conj: List[tokens] = ["between", "and"], BV1, BV2, expand = False) "A and B are ...."

    #     BV1(B(token="between", text ="grather than")) V(1)
    #     BV2(B(token="and" text = "less than")) V(10)

    #     "grather than 1 less than 10"
    #     "grather equal  than 1 less than 10"
