from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from transformers import TokenSpan
from nlp4re.utils.util import convert_to_capitalize_singular_noun
from nlp4re.spacy_config import nlp
from enum import Enum


@dataclass(frozen=True)  # The "frozen" parameter makes the class immutable
class Confidence(Enum):
    """Enumeration of Confidences
       Each SingleElement has one or more Confidences.
       Most ofConfidences are for a specific element.
    """

    Match = 0  # Confidence for elements which has a known text(s). - "after", "during", "during and after" for When element, "The", "Each", "Any" for Article element.
    Term = 1 # Confidence for a element when its a part or whole text is in the Term Definition excel file.
    StartsWith = 2 # Confidence of a element whose text starts with the "Start With" column words in the Patterns excel file.
    Pattern_of = 3 # Confidence of grouped elements (Section and Resource of SectionResource), when they are connected by "of" (ie., Section A of B).
    Pattern_resource_section = 4 # Confidence of grouped element(Section and Resrouce of SectionResource), when they has a pattern of RESOURCE followed by SECTION (i.e, DR&O Section 2.12)
    Pattern_DEP_after = 5 # Confidence of Condition/Event following a word in "After" column words of the Pattens excel file (i.e., exposed to salt spray)
    DEP_NsubjNsubjpass_ROOT = 6 # Confidence of Agent whose noun-chunk root is pointed from DEP:ROOT token as DEP:nsubj or DEP:nsubjpass.
    DEP_NsubjNsubjpass = 7 # Confidence of Agent whose noun-chunk root is DEP:nsubj or DEP:nsubjpass.
    Similar = 8 # Confidence of Agent whose noun-chunk text is similar to already identified Agent (ie., "The fuel tank" from already identified "The tank")
    Term_Unit = 9 # Confidence of Boundary and Value elements when the element is identified from the "Unit" of the Term Definitions.xlsx. 
    DET_This = 10 # Confidence of Section and Resource added when the word is already identified but having "this" in front of it.
    Agent_of = 11 # Confidence of Agent when the Agent is found from other identified agents (can be invalid ones too) connected by "of" (ie., "The Engine Bleed Air Temperature" from "The probability of engine bleed air temperature") 
    


@dataclass
class Element:
    """
    A class to represent all elements.

    ...
    Args
    -------
        ABC (_type_): _description_

    Methods
    -------
    abstract
        getTexts() -> [string]:
            returns text representation of the element use to create a requirement sentence.
    abstract
        getConfidenceValue() -> float
            returns a number to represent conficence of creating this element.  Larger the number has more confidence.
    abstract
        getTokens() -> [Tokens] = TokenSpan
    """

    @abstractmethod
    def getTexts(self):
        """abstract method
        returns text representation of the element use to create a requirement sentence.
        """
        pass

    @abstractmethod
    def getConfidenceValue(self):
        """abstract method
        returns a number to represent conficence of creating this element.  Larger the number has more confidence.
        """
        pass

    @abstractmethod
    def getTokens(self):
        """abstract metohd
        returns list of tokens used to create this element.
        """
        pass


@dataclass
class SingleOrGroupElement(Element):
    """subclass of Element
        superclass for SingleElement and ElementGroup
    ...
    Args
    -------
        Element (_type_): superclass of this class

    Methods
    -------
    abstract
        getFit() -> bool:
            returns text representation of the element use to create a requirement sentence.
    """

    @abstractmethod
    def getFit(self):
        """abstract method
        returns bool whether this element fit or not.  If fit is False, it requires a user to overwrite a text from this element.
        The list of invalid/unfit words are in Term Definition.xlsx and prefix with "*".
        For example, there is "*sensor" is listed !!!!!!!!!!!!!!!!.  When aThe "sensor" is likely to extracted as AGENT, so
        """
        pass


@dataclass
class ConjElements(Element):
    """Class for conjunction elements
       superclass of AgentsConj, SectionResourcesConj, BoundaryValueConj
        _conj (list of TokenSpan): conjuntion tokenspans for the connecting elements
        Examples
            1) text = "A and B ...." and having A and B Agents.  Then create AgentsConj from two Agents with _conj is ["and"] tokenspan and _expand = False
            2) text = .... between 1 and 5" and having two BoundaryValues [BoundaryValue(Boundary = "between", Value = 1), BoundaryValue(Boundary = "and", Value = 5)].
                From the two BoundaryValues create one BoundaryValueConj with _conj = ["between", "and"] tokenspans and expand = False
            3) text = ".... Section A of Resource A and Section B of Resource B..." and having two SectionResources
                `[SectionResource(Section= "Section A", Resource="Resource A"), SectionResource(Section= "Section B", Resource="Resource B")].
                From the two SectionResources, create one `SectionResourcesConj` with `_conj = ["and"]` and `_expand = True`.

        _conj_elements (list): list of Elements connected by the conjunction
            (ie., Section A and Section B, Agent1, Agent2, and Agent3)
        _expand(bool): if to create more than one sentences from this element.
    """

    _conj: "list[TokenSpan]"
    # AgentConj(oneToken,...) or AgentConj([oneToken, anotherToken]....) both work why?
    _conj_elements: "list[Element]"
    _expand: bool = False

    def getConj(self):  # string "and"
        """get method for _conj

        Returns:
            list[TokenSpan]: return the list of TokenSpan connected by _conj.
        """
        return self._conj

    def getExpand(self):
        """get method for _expand

        Returns:
            bool: return if the requirement
        """
        return self._expand

    def getElements(self):
        """get method for _conj_elements

        Returns:
            list of Element: return the list of _conj_elements.
        """
        return self._conj_elements

    def getTexts(self):
        """Retrieve the tokens of this object as a string.
            Return a list consisting of the conjunction text followed by a (nested) list of the conjoined text
            (ie., [["and", ["Section A of Resource", "Section B of ResourceB"]] )
        Returns:
            list[[Tokelist: conj text followed by list of element text
        """
        r = []
        # _conj : list[TokenSpan]
        # type (self._conj) = <class 'list'> if AgentConj(['and token', 'and token']...)
        # type (self._conj) = <class 'spacy.tokens.token.Token'> if AgentConj(['and token']....)
        if isinstance(self._conj, list):
            r.append([conj.text for conj in self._conj])
        else:
            r.append(self._conj.text)
        for e in self._conj_elements:
            r.append(e.getTexts())
        return r

    def getConfidenceValue(self):
        """get method for summed up elements confidence value
        Returns:
            float: sum of elements confidence values
        """
        c = 0
        for e in self._conj_elements:
            c = c + e.getConfidenceValue()
        return c

    def getTokens(self):
        """All tokens used by this object
           [andtoken, sectionAToken, resourceAToken, sectionBToken, resourceBToken]
        Returns:
            list: list of tokens
        """
        combined = []
        combined.append(self._conj)
        for e in self._conj_elements:
            combined.extend(list(e.getTokens()))
        return combined

    def info(self):
        """information of this object for debugging

        Returns:
            string: text representation of this object
        """
        r = f"{self},{self.getTexts()}, {self.getConfidenceValue()},\n"
        for i in range(len(self._conj_elements)):
            r += " (" + str(i) + ") " + self._conj_elements[i].info() + "\n"
        return r


@dataclass
class ElementGroup(SingleOrGroupElement):
    """_summary_

    _extended_summary_

    Args:
        SingleOrGroupElement (_type_): _description_
    """
    def __init__(
        self, a_key: Element, a_value: Element, b_key: Element, b_value: Element
    ):
        """subclass of SingleOrGroupElement
            superclass of SectionResource, BoundaryValue, ArticleAgent
        Args:
            _elements (dict): key = singleElement class (ie., Section), value = singleElement object (ie., instance of Section)
            _text (string): text representing ElementGroup (ie., "SectionA of ResourceB")
            _confidenceValue(float): sum up confidencevalues of contained elements
        """
        self._elements = {}
        self._elements[a_key] = a_value
        self._elements[b_key] = b_value

        self._texts = []  # initialize default value
        self._confidenceValue = None  # initialize default value

    def getFit(self):
        for v in self._elements.values():
            if v != None:
                if v.getFit() == False:
                    return False
        return True

    def getElements(self):
        """ identified GroupElement.  Superclass for SectionResource, BoundaryValue and ArticleAgent
            
        Returns:
            dist(key = SingleElement class, value = instance of the key class): identified group elements
        """
        return self._elements

    def getTexts(self):
        """required overwritten method

        Returns:
            list(String): text representation of an identified element.
        """
        if len(self._texts) == 0:
            self.setTexts()
        return self._texts


    def getTextsWithUnfit(self):
        """information purpose only, if more one text, it will display ** at end.

        Returns:
           String: getTexts() with ** if unfit word.
        """
        ts = ""
        postfix = ""
        if self.getFit() == False:
            postfix = "**"
        for t in self.getTexts():
            ts += ", " + t + postfix
        return ts[2:]

    def getConfidenceValue(self):
        """required overwritten method

        Returns:
            Float : sum of Confidences represented in float
        """
        if self._confidenceValue == None:
            self.setConfidenceValue()
        return self._confidenceValue

    def getTokens(self):
        """required overwritten method

        Returns:
            list[Tokens]: Tokens used to identify an element
        """
        combined = []
        for v in self._elements.values():
            if v != None:
                combined.extend(list(v.getTokens()))
        return combined

    @abstractmethod
    def setTexts(self):
        pass

    def setConfidenceValue(self):
        """ set conficence value by adding each element confidence value """
        s = 0
        for k, v in self._elements.items():
            if v != None:
                s = s + v.getConfidenceValue()
        self._confidenceValue = s

    def info(self):
        """information of this object for debugging

        Returns:
            string: text representation of this object
        """
        s = ""
        for k, v in self._elements.items():
            if v == None:
                s += k.__name__ + " = None , "
            else:
                s += v.info() + ", "
        return self.__class__.__name__ + " = [" + s[:-2] + "]"


@dataclass
class SingleElement(SingleOrGroupElement):
    """_summary_

    Args:
        SingleOrGroupElement (_type_): super type
    """

    def __init__(self, tokens: list, confidences: list, fit=True, texts: list = None):
        """
        The constructor to SingleElement
        Args:
            tokens (spacky's tokens = span): list of tokens for this Element.
            confidences ([Confidence(enum)]): list of Confidences for this Element
            fit (bool, optional): if False, this element requires a user modification (ie., "Section" to be modified as "Section 123"). Defaults to True.
            texts (list of string, optional) - list of texts of implied element if not empty list.  If empty list, then self._texts are created from tokens(span)
                default is None then self._texts are created from tokens.
                (ie., "-3.1F to 3.1F" ->
                    BoundaryValueConj( None,
                        [BoundaryValue( Boundary([], confidence.Term, texts=["greater than"]),
                                       Value([tokens = -3.1F], conf..),
                        BoundaryValue( Boundary([], confidence.Term, texts=["less than"]),
                                       Value([tokens = 3.1F], conf..)],
                        text = "and"
                    )
        """
        self._tokens = tokens  #: list[spacy.token] = spacy's span, or empty list [] when texts exist (implied element)
        self._confidences = confidences
        self._confidenceNames = (
            None
            if confidences == None
            else [confidence.name for confidence in confidences]
        )  #: str = field(default = "NA") #Before, After, Middle
        self._fit = fit

        # set _text from tokens
        if texts == None:
            self._texts = []
            self.setTexts()  # set using tokens
        else:
            self._texts = texts

        # set _confidenceValue from _confidences
        self._confidenceValue = None
        self.setConfidenceValue()

    def getConfidenceNames(self):
        """for information method for returning its text representation of confidence.
        """
        return self._confidenceNames

    def getTexts(self):
        """
        required overwritten method

        Returns:
        list of string: text representation of identified elements
        """
        return self._texts

    def getConfidences(self):
        """ get method for Confidenced

        Returns:
            list of Confidences: return list of Confidences for this element
        """
        return self._confidences
   
    def getConfidenceValue(self):
        """ get method for Confidence value
        Returns:
            float: confidence value for this element
        """
        return self._confidenceValue

    def getTokens(self):
        """returned over written method
        Returns:
            list of tokens: return list of tokens identified for this element 
        """
        return self._tokens

    # If each text is fit or not. The index is the same as texts
    def getFit(self):
        """return this element is 100% fit for this element.
        If getFit returns False, this element text requires modification (ie., "Section" to "Section 5.1")

        Returns:
           boolean: return whether this element is 100% fit for the element. 
           Unfit words are listed in Patterns.xlsx prefix with "*" (ie., "Section" )
        """
        return self._fit

    def info(self):
        """information representation for this element.

        Returns:
            String: detailed description for this element.
        """
        return f"{self.__class__.__name__} = {self.getTexts()}, {self.getConfidenceValue()}, {self.getConfidenceNames()}, {self.getFit()}"

    def getTextsWithUnfit(self):
        """information to represent text with "**" to show the element is unfit word.

        Returns:
            String: getTexts() + "**" to show unfit element in text.
        """
        if self._fit:
            return self.getTexts()
        else:
            r = []
            for t in self.getTexts():
                r.append(t + "**")
            return r

    # set fits in this method
    @abstractmethod
    def setTexts(self):
        """ Abstract method required to implemented by its subclass 
            To set this element's texts attribute.
        """
        pass

    @abstractmethod
    def setConfidenceValue(self):
        """ Abstract method required to implement by its subclass 
            To set this element's confidence value.
        """
        pass

    @staticmethod
    def calculateConfidenceValue(confidence_options, confidences):
        """Calculate/Sum confidence values based on confidence passed

        Args:
            confidence_options (dict): confidence options for this element (key(enum) = Element.confidence, value = integer)
            confidences (list of Confidences): confidences for this element

        Returns:
            c_value (float): calculated/sum up value for this element. This value can be more than 1.
            or
            c_value/sum(confidence_options.values()): this is c_value divided by sum of confidence_option values for this element.  This value is between 0-1.
        """
            
        c_value = 0
        for confidence in confidences:
            c_value += confidence_options[confidence.name]
        return c_value
        #return c_value / sum(confidence_options.values())

   

    def getConfidenceNames(self):
        """return this element's confidence in text format"""
        return self._confidenceNames

    def addConfidence(self, c):
        """Add method for Conficence

        Args:
            c (Confidence): Confidence to be added to this element
        """
        self._confidences.append(c)
        self._confidenceNames.append(c.name)
        self.setConfidenceValue()

    def toTitleCase_Agent(self, convert_to_singular=True):
        """Modify this element's text into Title calse (i.e, "crew oxgen hose" to Crew Oxgen Hose")
           If its text is all capital, then not modify (i.e., "ELMS" to "ELMS")
           This is specific to Agent element

        Args:
            convert_to_singular (bool, optional): default is True.  If True, modify the element text to singular form.

        Returns:
            String: TitleCase for this element text
        """
        capitalize = (
            lambda t: t.text if t.text.upper() == t.text else t.text.capitalize()
        )
        text = ""
        for i in range(len(self._tokens) - 1):
            if self._tokens[i].pos_ == "CCONJ":
                text = text + self._tokens[i].text + self._tokens[i].whitespace_
            else:
                text = text + capitalize(self._tokens[i]) + self._tokens[i].whitespace_

        last_token = self._tokens[len(self._tokens) - 1]
        # if last_token.tag_ in ["NNS", "NNPS"] : #plural - #https://cs.nyu.edu/~grishman/jet/guide/PennPOS.html NNS = Noun, plural
        if convert_to_singular:
            text = text + convert_to_capitalize_singular_noun(
                last_token,
                last_token.lemma_,
                next(t.lemma_ for t in nlp(last_token.text.lower())),
                True,
            )
        else:
            temp = text + capitalize(last_token)
            if temp.upper() == temp:
                text = temp
            else:  # "WAP Function Transducers" to "WAP Function Transducer"
                text = text + convert_to_capitalize_singular_noun(
                    last_token,
                    last_token.lemma_,
                    next(t.lemma_ for t in nlp(last_token.text.lower())),
                    True,
                )

        return text  

    def toTitleCase(self, includeSingular=False):
        """Modify this element's text into TitleCase (ie., "section 5" to "Section 5")
           If this element text is prefix with "the", "a" or "an", they are removed.
        Args:
            includeSingular (bool, optional): If this is True, add its singular form to texts (ei., "systems" to include "system" also)
   
        Returns:
            String: title case for this element's text form
        """
        capitalize = (
            lambda t: t.text if t.text.upper() == t.text else t.text.capitalize()
        )
        if (
            self._tokens[0].lemma_ == "the"
            or self._tokens[0].lemma_ == "a"
            or self._tokens[0].lemma_ == "an"
        ):
            text = ""
        elif len(self._tokens) == 1:
            text = ""
        else:  # len(self.tokens) != 1:
            text = capitalize(self._tokens[0]) + self._tokens[0].whitespace_
        for i in range(len(self._tokens) - 2):
            text = (
                text + capitalize(self._tokens[i + 1]) + self._tokens[i + 1].whitespace_
            )

        last_token = self._tokens[len(self._tokens) - 1]
        # if last_token.tag_ in ["NNS", "NNPS"] : #plural - #https://cs.nyu.edu/~grishman/jet/guide/PennPOS.html NNS = Noun,
        # s is Set (no duplicate)
        s = {text + capitalize(last_token)}
        if includeSingular:
            s.add(
                text
                + convert_to_capitalize_singular_noun(
                    last_token,
                    last_token.lemma_,
                    next(t.lemma_ for t in nlp(last_token.text.lower())),
                    True,
                )
            )
        return s

    def lemma_text(self):
        """
        Returns:
            String: lemma form of this element
        """
        lemma_text = ""
        for token in self._tokens:
            lemma_text = lemma_text + token.lemma_ + token.whitespace_
        return lemma_text.strip()
