from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence


@dataclass
class Event(SingleElement):
    """ Data class for Boundary element
    Args:
        SingleElement : this class's superclass
    """
    #confidence options for this element
    confidence_options = {
            Confidence.Term.name: 1.0,
            Confidence.Pattern_DEP_after.name: 0.8,
        }
    def __init__(self, tokens, confidences):
        """initialization - use superclass constructor"""
        super().__init__( tokens, confidences)  

    def setTexts(self):
        """Sets its texts based on tokens in title case.
        """
        for c in self.toTitleCase():
            self._texts.append(c)

    
    def setConfidenceValue(self):
        """
        Set confidenceValue based on its Confidence(s)
        """
        self._confidenceValue = SingleElement.calculateConfidenceValue(Event.confidence_options, self._confidences)

