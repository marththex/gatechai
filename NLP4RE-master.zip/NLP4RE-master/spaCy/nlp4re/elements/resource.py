from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence


@dataclass
class Resource(SingleElement):
    """ Data class for Boundary element
    Args:
        SingleElement : this class's superclass
    """
    #confidence options for this element
    confidence_options = {
        Confidence.Term.name: 1.0,
        Confidence.DET_This.name: 0.9,
        Confidence.Pattern_of.name: 0.9,
        Confidence.Pattern_resource_section.name: 0.9,
        Confidence.StartsWith.name: 0.8,
    }
    
    def __init__(self, tokens, confidences, fit=True, texts=None):
        """initialization - use superclass constructor"""
        super().__init__(tokens, confidences, fit, texts=texts)  

    def setTexts(self):
        """Sets its texts based on tokens in title case.
        """
        if self._tokens != None:
            for c in self.toTitleCase():
                self._texts.append(c)

    def setConfidenceValue(self):
        """Setting confidence value.
        If this element is created without tokens, then set its Confidence value as 0.
        Otherwise calculated based on its confidences.
        """
        if self._tokens == None:
            self._confidenceValue = 0
        else:
            self._confidenceValue = SingleElement.calculateConfidenceValue(Resource.confidence_options, self._confidences)

    