from dataclasses import dataclass
from nlp4re.elements.element import ElementGroup
from nlp4re.elements.section import Section
from nlp4re.elements.resource import Resource


@dataclass
class SectionResource(ElementGroup):
    """ Data class for SectionResource elemement.
        Subclass for ElementGroup.
    """
    def __init__(self, section, resource):
        """initialization - use superclass constructor"""
        super().__init__(Section, section, Resource, resource)

    def setTexts(self):
        """ Setting text for this element.  Combine texts of Section and Resource together to make Section "of" Resource.

        """
        """assert is added because assumes its Section/Resource should be none or should have one text"""
        assert (
            self._elements[Section] == None
            or len(self._elements[Section].getTexts()) == 1
        )
        assert (
            self._elements[Resource] == None
            or len(self._elements[Resource].getTexts()) == 1
        )
        s = (
            self._elements[Section].getTexts()[0] + " of"
            if self._elements[Section] != None
            else ""
        )
        s += (
            (" " + self._elements[Resource].getTexts()[0])
            if self._elements[Resource] != None
            else ""
        )
        self._texts = [s.strip()]

    def getTextsWithUnfit(self):
        """info method to put** of Section or Resource is unfit words"""
        s = (
            self._elements[Section].getTextsWithUnfit() + [" of"]
            if self._elements[Section] != None
            else [""]
        )
        r = (
            ([" "] + self._elements[Resource].getTextsWithUnfit())
            if self._elements[Resource] != None
            else [""]
        )
        return s + r

    def getStartEndIndex(self):
        """
        Finding start and last token index for this SectionResource element
           TODO:
           in the case Section or Resource is implied Element (no token)
           Maybe should handle in SectionResourceParser to create ConjElement
        Returns:
            [int, int]: start and end index in 2-D array
        """
        s: Section = self._elements[Section]
        r: Resource = self._elements[Resource]
        if s == None:  # then r must be not None
            if len(r.getTokens()) > 0:
                end = r.getTokens().end
                start = r.getTokens().start
            else:  # r is implied element
                end = None
                start = None
        elif r == None:  # then s must be not None
            if len(s.getTokens()) > 0:
                start = s.getTokens().start
                end = s.getTokens().end
            else:  # s is implied element
                start = None
                end = None
        else:
            start = min(s.getTokens().start, r.getTokens().start)
            end = max(s.getTokens().end, r.getTokens().end)

        return [start, end]
