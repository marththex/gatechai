from dataclasses import dataclass
from nlp4re.elements.element import ConjElements


@dataclass
class SectionResourcesConj(ConjElements):
    """
    Data class of list of SectionResource elements connected by 'and'

    For example, SectionResource extracted are  'Section1 of Resource1' and 'Section2 of Resource2' from the original text 'Section1 of Resource1 and Section2 of Resource2',
    self._conj = "and" token
    self._conj_elements = [SectionResource(Section(text = 'Section1'), Resrouce(text = 'Resource1')) ,
                           SectionResource(Section(text = 'Section2'), Resrouce(text = 'Resource2'))]

    """
    _expand: bool = True
