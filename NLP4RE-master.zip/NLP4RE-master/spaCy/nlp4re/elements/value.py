from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence


@dataclass
class Value(SingleElement):
    """ Data class for Boundary element
    Args:
        SingleElement : this class's superclass
    """
    #confidence options for this element
    confidence_options = {
            Confidence.Term_Unit.name: 1.0
    }  
    
    def __init__(self, tokens, confidences):
        """initialization - use superclass constructor"""
        super().__init__(
            tokens, confidences
        )  

    def setTexts(self):
        """Sets its texts based on tokens
        """
        self._texts.append(self._tokens.text)

    def setConfidenceValue(self):
        """
        Set confidenceValue based on its Confidence(s)
        """
        if self._tokens == None:
            self._confidenceValue = 0
        else:
            self._confidenceValue = SingleElement.calculateConfidenceValue(Value.confidence_options, self._confidences)

   