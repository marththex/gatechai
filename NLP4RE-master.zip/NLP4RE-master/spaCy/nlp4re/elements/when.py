from dataclasses import dataclass
from nlp4re.elements.element import SingleElement, Confidence


@dataclass
class When(SingleElement):
    """ Data class for When ("after", "during", and "during and after") element
        Subclass for SingleElement
    """
    def __init__(self, tokens):
        """initialization - use superclass constructor"""
        super().__init__(tokens, [Confidence.Match])

    def setTexts(self):
        """Sets its texts based on tokens in title case."""
        self._texts.append(self._tokens.text)

    def setConfidenceValue(self):
        """When confidence is always Confidence.Match.  So simply set as 1.0 here.
        """
        self._confidenceValue = 1.0 #Confidence.Match
