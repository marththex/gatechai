from dataclasses import dataclass
from nlp4re.parser.article_agent_parser import ArticleAgentParser
from nlp4re.handler.requirement_handler import Requirement_Handler
from nlp4re.parser.boundary_value_parser import BoundaryValueParser
from nlp4re.parser.section_resource_parser import SectionResourceParser
from nlp4re.parser.article_agent_parser import ArticleAgentParser
from nlp4re.parser.state_parser import StateParser
from nlp4re.parser.condition_parser import ConditionParser
from nlp4re.parser.event_parser import EventParser
from nlp4re.parser.characteristic_parser import CharacteristicParser
from nlp4re.parser.object_parser import ObjectParser

@dataclass
class Design_Handler(Requirement_Handler):
    """A class that uses various element parsers to parse a design requirment sentence, identify elements, and add the identified elements in self._elements

    Args:
        Requirement_Handler (class): its super class
    Methods:
        (void) process_line: process a sentence    
    """
    #Term Definition information for SECTION
    [
        SectionResourceParser.s_term_matcher,
        SectionResourceParser.s_dict_terms,
        SectionResourceParser.s_invalids,
        SectionResourceParser.s_unfits,
    ] = Requirement_Handler.term_def_info["SECTION"]

    #Term Definition information for RESOURCE
    [
        SectionResourceParser.r_term_matcher,
        SectionResourceParser.r_dict_terms,
        SectionResourceParser.r_invalids,
        SectionResourceParser.r_unfits,
    ] = Requirement_Handler.term_def_info["RESOURCE"]

    #Patterns's Start with column information for SECTION
    SectionResourceParser.s_startwith = Requirement_Handler.pattern_dict["SECTION"]["Start with"]
    
    #Patterns's Start with column information for RESOURCE
    SectionResourceParser.r_startwith = Requirement_Handler.pattern_dict["RESOURCE"]["Start with"]

    #Term Definition information for AGENT
    [
        ArticleAgentParser.a_term_matcher,
        ArticleAgentParser.a_dict_terms,
        ArticleAgentParser.invalids,
        ArticleAgentParser.unfits,
    ] = Requirement_Handler.term_def_info["OBJECT"]
    #Term Definition information for BOUNDARY
    [
        BoundaryValueParser.b_term_matcher,
        BoundaryValueParser.b_dict_terms,
        BoundaryValueParser.b_invalids,
        BoundaryValueParser.b_unfits,
    ] = Requirement_Handler.term_def_info["BOUNDARY"]
    #Term Definition information for VALUE
    [
        BoundaryValueParser.v_term_matcher,
        BoundaryValueParser.v_dict_terms,
        BoundaryValueParser.v_invalids,
        BoundaryValueParser.v_unfits,
    ] = Requirement_Handler.term_def_info["VALUE"]
    #Term Definition information for CONDITION
    [
        ConditionParser.c_term_matcher,
        ConditionParser.c_dict_terms,
        ConditionParser.c_invalids,
        ConditionParser.c_fits,
    ] = Requirement_Handler.term_def_info["CONDITION"]
    #Patterns's After column information for CONDITION
    ConditionParser.c_afters = Requirement_Handler.pattern_dict["CONDITION"]["After"]

    [
        EventParser.e_term_matcher,
        EventParser.e_dict_terms,
        EventParser.e_invalids,
        EventParser.e_fits,
    ] = Requirement_Handler.term_def_info["EVENT"]
    #Patterns's After column information for Event
    EventParser.c_afters = Requirement_Handler.pattern_dict["EVENT"]["After"]


    #Term Definition information for STATE
    [
        StateParser.s_term_matcher,
        StateParser.s_dict_terms,
        StateParser.s_invalids,
        StateParser.s_fits,
    ] = Requirement_Handler.term_def_info["STATE"]

    [
        CharacteristicParser.c_term_matcher,
        CharacteristicParser.c_dict_terms,
        CharacteristicParser.c_invalids,
        CharacteristicParser.c_fits,
    ] = Requirement_Handler.term_def_info["CHARACTERISTIC"]
    CharacteristicParser.c_afters = Requirement_Handler.pattern_dict["CHARACTERISTIC"]["After"]

    #Term Definition information for OBJECT
    [
        ObjectParser.o_term_matcher,
        ObjectParser.o_dict_terms,
        ObjectParser.invalids,
        ObjectParser.unfits,
    ] = Requirement_Handler.term_def_info["OBJECT"]
 

    def process_line(self, l, line_number=0):
        """ use element parsers to parse a line of text and identify elements and add in self._elements for Design requirement.
        Order of Parser does not change the outcome of results.
        Args:
            l (string): string of a requirement sentense.
            line_number (int, default = 0): available if you would like display the line number of a sentense
        """
        super().preprocess(l)

        run = {
            "BOUNDARYVALUE": True,
            "SECTIONRESOURCE": True,
            "AGENT": True,
            "STATE": True,
            "CONDITION": True,
            "CHARACTERISTIC": True,
            "OBJECT": True, 
            "EVENT" : True,
        }
        if run["BOUNDARYVALUE"]:
            bv = BoundaryValueParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            bv_elements = bv.process()
            self._elements.extend(bv_elements)
    
        if run["AGENT"]:
            aw2 = ArticleAgentParser(self._line, self._doc, line_number, self._list_noun_chunks)
            aw_elements2 = aw2.process()
            self._elements.extend(aw_elements2)
      
        if run["SECTIONRESOURCE"]:
            srw = SectionResourceParser(self._line, self._doc, line_number, self._list_noun_chunks)
            sr_elements = srw.process()
            self._elements.extend(sr_elements)
  
        if run["STATE"]:
            st = StateParser(self._line, self._doc, line_number, self._list_noun_chunks)
            st_elements = st.process()
            self._elements.extend(st_elements)
 
        if run["CONDITION"]:
            cw = ConditionParser(self._line, self._doc, line_number, self._list_noun_chunks)
            cw_elements = cw.process()
            self._elements.extend(cw_elements)
        
        if run["CHARACTERISTIC"]:
            chw = CharacteristicParser(self._line, self._doc, line_number, self._list_noun_chunks)
            chw_elements = chw.process()
            self._elements.extend(chw_elements)
  
        if run["OBJECT"]:
            op = ObjectParser(self._line, self._doc, line_number, self._list_noun_chunks)
            op_elements = op.process()
            self._elements.extend(op_elements)
  
        if run["EVENT"]:
            ep = EventParser(self._line, self._doc, line_number, self._list_noun_chunks)
            ep_elements = ep.process()
            self._elements.extend(ep_elements)    

if __name__ == "__main__":
    #initializing Environment Handler
    hw = Design_Handler()
    #if runAll is False run a sentence below, if All is True run all sentences from excel file
    runAll = True

    ########################################
    # test with single requirement sentence
    ########################################

    if not runAll:
        #process the sentence below and print out the information.
        hw.process_line("The output spline shall be sized to carry a limit and ultimate load equal to the jam torque specified in paragraph 3.3.1.3.")
        #print out information
        hw.printDetails()

    #################################
    # test with multiple requirements 
    #################################
    
    if runAll:
        # reading the requirements from the specified excel file, process a sentence and print out information sentence by sentence.
        # specify the excel file    
        requirements_filename = "nlp4re/Design Reqs Manual Conversion - Final.xlsx"
        #specify tab name of the excel file
        requirements_file_tab_name = "Boeing_design_boilerplates"
        #specify column name of the excel file
        requirements_file_column_name = "Requirement Text"
         #defining the excel file information
        requirements_excel_file = {
            "name": requirements_filename,
            "tab": requirements_file_tab_name,
            "column": requirements_file_column_name,
        }
        #parse all requirements, parse and print out information sentence by sentence. 
        hw.process_lines_excel(requirements_excel_file)
