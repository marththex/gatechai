from dataclasses import dataclass
from nlp4re.handler.requirement_handler import Requirement_Handler
from nlp4re.parser.article_agent_parser import ArticleAgentParser
from nlp4re.parser.section_resource_parser import SectionResourceParser
from nlp4re.parser.condition_event_parser import ConditionEventParser
from nlp4re.parser.when_parser import WhenParser
from nlp4re.parser.boundary_value_parser import BoundaryValueParser

@dataclass
class Environment_Handler(Requirement_Handler):
    """A class that uses various element parsers to parse a envirnment requirment sentence, identify elements, and add the identified elements in self._elements

    Args:
        Requirement_Handler (class): its super class

    Methods:
        (void) process_line: process a sentence

    """
    #Term Definition information for SECTION
    [
        SectionResourceParser.s_term_matcher,
        SectionResourceParser.s_dict_terms,
        SectionResourceParser.s_invalids,
        SectionResourceParser.s_unfits,
    ] = Requirement_Handler.term_def_info[
        "SECTION"
    ] 
    #Term Definition information for RESOURCE
    [
        SectionResourceParser.r_term_matcher,
        SectionResourceParser.r_dict_terms,
        SectionResourceParser.r_invalids,
        SectionResourceParser.r_unfits,
    ] = Requirement_Handler.term_def_info[
        "RESOURCE"
    ]  
    #Patterns's Start with column information for SECTION
    SectionResourceParser.s_startwith = Requirement_Handler.pattern_dict["SECTION"][
        "Start with"
    ]
    #Patterns's Start with column information for RESOURCE
    SectionResourceParser.r_startwith = Requirement_Handler.pattern_dict["RESOURCE"][
        "Start with"
    ]
    #Term Definition information for CONDITION
    [
        ConditionEventParser.c_term_matcher,
        ConditionEventParser.c_dict_terms,
        ConditionEventParser.c_invalids,
        ConditionEventParser.c_fits,
    ] = Requirement_Handler.term_def_info["CONDITION"]
    #Term Definition information for EVENT
    [
        ConditionEventParser.e_term_matcher,
        ConditionEventParser.e_dict_terms,
        ConditionEventParser.e_invalids,
        ConditionEventParser.e_fits,
    ] = Requirement_Handler.term_def_info["EVENT"]
    #Patterns's After column information for CONDITION
    ConditionEventParser.c_afters = Requirement_Handler.pattern_dict["CONDITION"]["After"]
    #Term Definition information for AGENT
    [
        ArticleAgentParser.a_term_matcher,
        ArticleAgentParser.a_dict_terms,
        ArticleAgentParser.invalids,
        ArticleAgentParser.unfits,
    ] = Requirement_Handler.term_def_info["OBJECT"]
    #Term Definition information for BOUNDARY
    [
        BoundaryValueParser.b_term_matcher,
        BoundaryValueParser.b_dict_terms,
        BoundaryValueParser.b_invalids,
        BoundaryValueParser.b_unfits,
    ] = Requirement_Handler.term_def_info["BOUNDARY"]
    #Term Definition information for VALUE
    [
        BoundaryValueParser.v_term_matcher,
        BoundaryValueParser.v_dict_terms,
        BoundaryValueParser.v_invalids,
        BoundaryValueParser.v_unfits,
    ] = Requirement_Handler.term_def_info["VALUE"]

    def process_line(self, line: str, line_number: int = 0):
        """ Process a single line (a.k.a document) with the spaCy NLP model.
        Parse a line of text and identify elements and 
        add to `self._elements` for Environment requirements.
        Order of Parser does not change the outcome of results.d

        Args:
            line (str): The input line/sentence.
            line_number (int): The index/count of this input line within the source data (text file).
        """

        super().preprocess(line)
     
        """ Add dictionary variable to control which element extraction to run """
        run = {
            "BOUNDARYVALUE": True,
            "SECTIONRESOURCE": True,
            "WHEN": True,
            "CONDITION": True,
            "AGENT": True,
        }

        if run["BOUNDARYVALUE"]:
            bv = BoundaryValueParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            bv_elements = bv.process()
            self._elements.extend(bv_elements)
     
        if run["SECTIONRESOURCE"]:
            srw = SectionResourceParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            sr_elements = srw.process()
            self._elements.extend(sr_elements)
   
        if run["WHEN"]:
            # # # #when - during, during and after, after
            when = WhenParser(self._line, self._doc, line_number, None)
            when_elements = when.process()
            self._elements.extend(when_elements)

        #condition
        if run["CONDITION"]:
            cw = ConditionEventParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            cw_elements = cw.process()
            self._elements.extend(cw_elements)

        if run["AGENT"]:
            aw = ArticleAgentParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            aw_elements = aw.process()
            self._elements.extend(aw_elements)

if __name__ == "__main__":
    #initializing Environment Handler
    esw = Environment_Handler()

    #if runAll is False run a sentence below, if All is True run all sentences from excel file
    runAll = True
    
    ########################################
    # test with single requirement sentence
    ########################################
    if not runAll:
        #process the sentence below and print out the information.
        esw.process_line('The WAP shall operate correctly in the environment specified by section 4.6.3 of this SCD or DRO section 2.12.')
        #print out information
        esw.printDetails()
       
    #################################
    # test with multiple requirements
    #################################
    if runAll:
        # reading the requirements from the specified excel file, process a sentence and print out information sentence by sentence.
        # specify the excel file    
        requirements_filename = (
            "nlp4re/Env Reqs Manual Conversion - Final - Compare.xlsx"
        )
        #specify tab name of the excel file
        requirements_file_tab_name = "compare"
        #specify column name of the excel file
        requirements_file_column_name = "Original"
        #defining the excel file information
        requirements_excel_file = {
            "name": requirements_filename,
            "tab": requirements_file_tab_name,
            "column": requirements_file_column_name,
        }
        #parse all requirements, parse and print out information sentence by sentence.
        esw.process_lines_excel(requirements_excel_file)
