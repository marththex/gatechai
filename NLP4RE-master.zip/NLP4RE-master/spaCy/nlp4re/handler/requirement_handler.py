from abc import abstractmethod
from nlp4re.spacy_config import nlp
from nlp4re.utils.util import read_excel 
from nlp4re.utils.matcher_terms import get_term_def_info, get_pattern_dict
from nlp4re.elements.element import ConjElements, SingleElement, ElementGroup, Element
from dataclasses import field, dataclass
from spacy.tokens import Doc


@dataclass
class Requirement_Handler:
    """ abstract class 
        Handler(Parser) to parse a requirement text and create Elements."""


    term_def_info = get_term_def_info()
    """create spacy's matcher by reading Term Definition excel's [Name', 'Acronym','Aliases', 'Units'] columns (see mather_terms.term_column_names)
       The matcher can pick up for only the exact match word.  For example, Term Definition defined "hours", but is the text contain "hour", then
       the matcher can't pick up the word.

    Returns:
        dict: Term Definition information (key(string) = element name, value(dict) = the information in the tab)
    """
    pattern_dict = get_pattern_dict()
    """create dictionary by reading Patterns excel file.  Key = column header, values are string arrays.
    """

    _elements: "list[Element]" = field(default_factory=list)

    _doc: Doc = None
    """(Language): The loaded/trained nlp object (language model).  [FIXME: review]"""

    def reset(self):
        """resetting elements"""
        self._elements = []  # list[Element] #[]

    def preprocess(self, line):
        """Precondition input data to simplify NLP processing.

        This method MUST be called by implememtations of `process()` before 

        Perform any of a number of cleanups on input data before application of any NLP analysis.
        Presently, this is mostly a number of simple or patterned replacements, but any other
        type of well-defined and consistent pre-NLP modifications can be added here.

        Args:
            line (str): The raw input document.  Will be 
        """
        self.reset()
        ############## pre-process ##########################
        # remove empty space front and end of a sentence
        line = line.strip()
        # removing "." from end of line
        # to pick up DR&O in RESOURCE(TERM) - with . at the end, "DR&O." is token.  Remove end ".", the token become "DR&O"
        #'To ensure a sanitized surface, the HSTA shall meet all requirements of this SCD after exposure to Fungus Resistance in accordance with Section 2.12 of DR&O.'
        if line.endswith('.'):
            line = line[: len(line) - 1]
        #replace multiple whitespaces with single whitespace
        line = " ".join(line.split())
        ################################################
        self._line = line
        self._doc = nlp(self._line)
        self._list_noun_chunks = list(self._doc.noun_chunks)

    @abstractmethod
    def process_line(self, line, line_number=0):
        """Abstract method required to be implemented by inherited classes

        Args:
            line (String): a sentence 
            line_number (int, optional): line number of requirements if process by reading excel file.  Used for debugging. 
        """
        pass

    
    def process_lines_excel(self, requirement_file):
        """ Process all sentences in the specified column(s) of the specified
        tab in the input Excel file and summarize the results.

        Args:
            requirement_file (dict[str,str]): Input Excel filename, sheet name, and column name(s).
        """
        # read Excel file input
        lines = read_excel(
            requirement_file["tab"],
            [requirement_file["column"]],
            requirement_file["name"],
        )[requirement_file["column"]]
        line_number = 0
        for line in lines:                          # process line by line
            line_number += 1
            self.process_line(line, line_number)    # process current line
            self.print_summary(line_number)          # output results

    def print_summary(self, k=-1):
        end=''
        sep=' / '
        if k>0:
            print(k,end=': ')

        # if len(self._elements) == 0:
        #     print(k)
        for e in self._elements:
            if issubclass(type(e), SingleElement):
                print(f"::{e.__class__.__name__}: {e.getTexts()}({e.getConfidenceValue()})", end=end)
            elif isinstance(e, ElementGroup):
                print(f"::{e.__class__.__name__}: {e.getTexts()}({e.getConfidenceValue()}) (", end=end)
                for key, v in e.getElements().items():  # getElements = Dictionary
                    if v != None:
                        if isinstance(v, SingleElement):  # SectionResource, BoundaryValue, ArticleAgent
                            print(f": {v.__class__.__name__}: {v.getTexts()} ({v.getConfidenceValue()}) ", end=end)
                print(" )", end=end)
            elif isinstance(e, ConjElements):
                print(f"::{e.__class__.__name__}: {e.getTexts()}({e.getConfidenceValue()}): (", end=end)
                for v in e.getElements():
                    if isinstance(v, SingleElement):
                        print(f"{v.__class__.__name__}: {v.getTexts()}({v.getConfidenceValue()})", end=end)
                    elif isinstance(v, ElementGroup):  # ConjElement with SectionResource, BoundaryValue
                        print(f"> {v.__class__.__name__}: {v.getTexts()}({v.getConfidenceValue()}): {{", end=end)
                        for (k2, v2) in v.getElements().items():  # getElements = Dictionary
                            if isinstance(v2, SingleElement):
                                print(f">> {v2.__class__.__name__}: {v2.getTexts()}({v2.getConfidenceValue()}) ", end=end)
                        print(" }", end=end)
                print(" )", end=end)
            #         else:
            #             print()
            # else:
            #     print()
        print()


    def printDetails(self, k=-1):
        """ used for debugging.
            print detailed string representation of elements
        
        """
        end=''
        sep=' / '
        if k>0:
            print(k,end=': ')

        # if len(self._elements) == 0:
        #     print(k)
        for e in self._elements:
            if issubclass(type(e), SingleElement):
                print(e.__class__.__name__, e.getTexts(), e.getConfidenceValue(), e.getConfidenceNames(), e.getFit(), end=end, sep=sep)
            elif isinstance(e, ElementGroup):
                print(e.__class__.__name__, e.getTexts(), e.getConfidenceValue(), e.getFit(), end=end, sep=sep)
                for key, value in e.getElements().items():  # getElements = Dictionary
                    if value != None:
                        if isinstance(value, SingleElement):  # SectionResource, BoundaryValue, ArticleAgent
                            print( "\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(),
                                value.getConfidenceNames(), value.getFit(), end=end, sep=sep)
            elif isinstance(e, ConjElements):
                print(e.__class__.__name__, e.getTexts(), e.getConfidenceValue(), end=end, sep=sep)
                for value in e.getElements():
                    if isinstance(value, SingleElement):
                        print("\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(),
                         value.getConfidenceNames(), value.getFit(), end=end, sep=sep)
                    elif isinstance(value, ElementGroup):  # ConjElement with SectionResource, BoundaryValue
                        print("\t", value.__class__.__name__, value.getTexts(), value.getConfidenceValue(), value.getFit(), end=end, sep=sep)
                        for (key2, value2) in value.getElements().items():  # getElements = Dictionary
                            if isinstance(value2, SingleElement):
                                print("\t\t", value2.__class__.__name__, value2.getTexts(), value2.getConfidenceValue(),
                                    value2.getConfidenceNames(), value2.getFit(), end=end, sep=sep)
            #         else:
            #             print()
            # else:
            #     print()
            print()

    def getElements(self):
        """ return parsed elements in list
        Returns:
            list[`Element`]: parsed elements
        """
        return self._elements


    def getDoc(self) -> Doc:  # FIXME: review [type]
        """
        Return spacy's doc (https://spacy.io/api/doc) for parsed text.

        Doc.__getitem__ METHOD
        Get a Token object at position i, where i is an integer. Negative indexing is supported, and follows the usual Python semantics, i.e. doc[-2] is doc[len(doc) - 2].

        Doc.__iter__ METHOD
            Iterate over Token objects, from which the annotations can be easily accessed.
            assert [t.text for t in doc] == ["Give", "it", "back"]

        Doc.__len__ METHOD
            Get the number of tokens in the document.
        """
        return self._doc

    def elements2str(elements, details=False):
        """ Used for debugging.

        Args:
            elements (list): list of elements to evaluated
            details (bool, optional): if False, just return the element in texts.  If True, plus detained information (ie., Confidence)

        Returns:
            String: string representation of elements
        """
        values = []
        if details:
            for e in elements:
                values.append(e.info())
            return values
        for e in elements:
            value = ""
            if isinstance(e, SingleElement):
                value += ", ".join(e.getTextsWithUnfit())
            elif isinstance(e, ElementGroup):
                value += ", ".join(e.getTextsWithUnfit())
            else:  # ConjElements
                for l in e.getTexts():
                    value += str(l)

            values.append(value)
        # remove enclosed '' using[1:-1] , A','B -> A,B
        value = (
            str(values)
            .replace("[", "")
            .replace("]", "")
            .replace("', '", ", ")
            .strip()[1:-1]
        )
        return value
