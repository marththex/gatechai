from dataclasses import dataclass
from nlp4re.parser.section_resource_parser import SectionResourceParser
from nlp4re.handler.requirement_handler import Requirement_Handler
from nlp4re.parser.condition_event_parser import ConditionEventParser
from nlp4re.parser.state_parser import StateParser
from nlp4re.parser.when_parser import WhenParser
from nlp4re.parser.boundary_value_parser import BoundaryValueParser
from nlp4re.parser.characteristic_parser import CharacteristicParser
from nlp4re.parser.article_agent_parser import ArticleAgentParser

@dataclass
class Suitability_Handler(Requirement_Handler):
    """A class that uses various element parsers to parse a suitability requirment sentence, identify elements, and add the identified elements in self._elements

    Args:
        Requirement_Handler (class): its super class
    Methods:
        (void) process_line: process a sentence    
    """
    
    #Term Definition information for SECTION
    [
        SectionResourceParser.s_term_matcher,
        SectionResourceParser.s_dict_terms,
        SectionResourceParser.s_invalids,
        SectionResourceParser.s_unfits,
    ] = Requirement_Handler.term_def_info["SECTION"]

    #Term Definition information for RESOURCE
    [
        SectionResourceParser.r_term_matcher,
        SectionResourceParser.r_dict_terms,
        SectionResourceParser.r_invalids,
        SectionResourceParser.r_unfits,
    ] = Requirement_Handler.term_def_info["RESOURCE"]

    #Patterns's Start with column information for SECTION
    SectionResourceParser.s_startwith = Requirement_Handler.pattern_dict["SECTION"]["Start with"]

    #Patterns's Start with column information for RESOURCE
    SectionResourceParser.r_startwith = Requirement_Handler.pattern_dict["RESOURCE"]["Start with"]

    #Term Definition information for CONDITION
    [
        ConditionEventParser.c_term_matcher,
        ConditionEventParser.c_dict_terms,
        ConditionEventParser.c_invalids,
        ConditionEventParser.c_fits,
    ] = Requirement_Handler.term_def_info["CONDITION"]
    #Term Definition information for EVENT
    [
        ConditionEventParser.e_term_matcher,
        ConditionEventParser.e_dict_terms,
        ConditionEventParser.e_invalids,
        ConditionEventParser.e_fits,
    ] = Requirement_Handler.term_def_info["EVENT"]
   
    #Patterns's After column information for CONDITION
    ConditionEventParser.c_afters = Requirement_Handler.pattern_dict["CONDITION"]["After"]

    #Term Definition information for STATE
    [
        StateParser.s_term_matcher,
        StateParser.s_dict_terms,
        StateParser.s_invalids,
        StateParser.s_fits,
    ] = Requirement_Handler.term_def_info["STATE"]
    #Term Definition information for AGENT
    [
        ArticleAgentParser.a_term_matcher,
        ArticleAgentParser.a_dict_terms,
        ArticleAgentParser.invalids,
        ArticleAgentParser.unfits,
    ] = Requirement_Handler.term_def_info["OBJECT"]
    #Term Definition information for BOUNDARY
    [
        BoundaryValueParser.b_term_matcher,
        BoundaryValueParser.b_dict_terms,
        BoundaryValueParser.b_invalids,
        BoundaryValueParser.b_unfits,
    ] = Requirement_Handler.term_def_info["BOUNDARY"]
    #Term Definition information for VALUE
    [
        BoundaryValueParser.v_term_matcher,
        BoundaryValueParser.v_dict_terms,
        BoundaryValueParser.v_invalids,
        BoundaryValueParser.v_unfits,
    ] = Requirement_Handler.term_def_info["VALUE"]
    #Term Definition information for CHARACTERISTIC
    [
        CharacteristicParser.c_term_matcher,
        CharacteristicParser.c_dict_terms,
        CharacteristicParser.c_invalids,
        CharacteristicParser.c_fits,
    ] = Requirement_Handler.term_def_info["CHARACTERISTIC"]

    CharacteristicParser.c_afters = Requirement_Handler.pattern_dict["CHARACTERISTIC"]["After"]
    # CharacteristicParser.c_befores = Requirement_Handler.pattern_dict["CHARACTERISTIC"]["Before"]

    def process_line(self, l, line_number=0):
        """ use element parsers to parse a line of text and identify elements and
        add in `self._elements` for Suitability requirement.
        Order of Parser does not change the outcome of results.
        Args:
            l (string): string of a requirement sentence.
            line_number (int, default = 0): available if you would like display the line number of a sentense
        """
        super().preprocess(l)

        run = {
            "BOUNDARYVALUE": True,
            "SECTIONRESOURCE": True,
            "WHEN": True,
            "CONDITION": True,
            "STATE": True,
            "CHARACTERISTIC": True,
            "AGENT": True,
        }
        if run["BOUNDARYVALUE"]:
            bv = BoundaryValueParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            bv_elements = bv.process()
            self._elements.extend(bv_elements)
 
        if run["SECTIONRESOURCE"]:
            srw = SectionResourceParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            sr_elements = srw.process()
            self._elements.extend(sr_elements)
        
        if run["WHEN"]:
            # #when - during, during and after, after
            when = WhenParser(self._line, self._doc, line_number, None)
            w_elements = when.process()
            self._elements.extend(w_elements)

 
        if run["CONDITION"]:
            # # #condition
            cw = ConditionEventParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            cw_elements = cw.process()
            self._elements.extend(cw_elements)

    
        if run["STATE"]:
            sw = StateParser(self._line, self._doc, line_number, self._list_noun_chunks)
            sw_elements = sw.process()
            self._elements.extend(sw_elements)
  
    
        if run["CHARACTERISTIC"]:
            chw = CharacteristicParser(
                self._line, self._doc, line_number, self._list_noun_chunks
            )
            chw_elements = chw.process()
            self._elements.extend(chw_elements)

    
        if run["AGENT"]:
            #agent###
            aw = ArticleAgentParser(self._line, self._doc, line_number, self._list_noun_chunks)
            aw_elements = aw.process()
            self._elements.extend(aw_elements)

            #update_excel_no_save("nlp4re/suitability_manual.xlsx", "AGENT", "J"+ str(line_number+1), Requirement_Handler.elements2str(aw_elements,True))
 
# import xlwings as xw
# def update_excel_no_save(filename, sheet_name, cell_id, value):
#     # update one line at a time
#     wb = xw.Book(filename)
#     sheet = wb.sheets[sheet_name]
#     sheet.range(cell_id).value = value


if __name__ == "__main__":
    #initializing Environment Handler
    esw = Suitability_Handler()

    #if runAll is False run a sentence below, if All is True run all sentences from excel file
    runAll = True
    ########################################
    # test with single requirement sentence 
    ########################################
    
    if not runAll:
        #process the sentence below and print out the information.
        esw.process_line("The probability that a given ELMS channel interface causes undetected corruption of a discrete input shall be less than 1.3E-1 per flight hour, excluding test interfaces and program pins.")
        #print out information
        esw.printDetails()
   
    ##################################
    # test with multiple requirements
    ##################################
    if runAll:
        # reading the requirements from the specified excel file, process a sentence and print out information sentence by sentence.
        # specify the excel file    
        requirements_filename = "nlp4re/suitability_manual.xlsx"
        #specify tab name of the excel file
        requirements_file_tab_name = "compare"
        #specify column name of the excel file
        requirements_file_column_name = "Original"
        #defining the excel file information
        requirements_excel_file = {
            "name": requirements_filename,
            "tab": requirements_file_tab_name,
            "column": requirements_file_column_name,
        }
        #parse all requirements, parse and print out information sentence by sentence.
        esw.process_lines_excel(requirements_excel_file)

   