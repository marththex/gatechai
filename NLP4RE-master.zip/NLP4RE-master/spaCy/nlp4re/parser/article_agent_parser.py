from dataclasses import dataclass, field
from nlp4re.utils.util import find_nounchunks_for_matcher
from nlp4re.parser.element_parser import ElementParser
from nlp4re.elements.agents_conj import AgentsConj
from nlp4re.elements.element import Confidence
from nlp4re.elements.article_agent import ArticleAgent
from nlp4re.elements.agent import Agent
from nlp4re.elements.article import Article, Enum_Article

@dataclass
class ArticleAgentParser(ElementParser):
    """ Parser class for parsing a line of text and creating Agent Element
        Subclass of an abstract ElementParser

        Parameters:
            _agent (list of ArticleAgent) : The grouped element identified by this parser
    """
    _agents: list[ArticleAgent] = field(default_factory=list)
    

    def process(self):
        """  
        required method that call find_agnts method, assign to _agent, and return the _agents (list of ArticleAgent identified) 
        
        Returns:
            List[ArticleAgent]: identified elements
        """
        
        self._agents = self.find_agents()
        return self._agents

    def find_agents(self):
        """
        Parsing a line of text and identifying ArticleAgents.

        Returns:
            list[ArticleAgent]: identified elements
        """
        # term_matched_words_dict(dict): key(Span) = a matched phrase, value(Span) = a noun_chunk contains the matched phrase
        # i.e.  [{key ="The slide/raft", value= "The slide/raft"}, {key = "slide/raft", value = "The slide/raft"}]
        # i.e., [{key = "an APU Fire", value = "an APU Fire"},{key = "APU", value = "an APU Fire"}]
        term_definition_matched_span_dict = find_nounchunks_for_matcher( self._doc, ArticleAgentParser.a_term_matcher, self._line, self._list_noun_chunks, False)
        # finding nounc-hunks whose root is DEP(nsub/jsubjpass) connected from DEP:ROOT or not connected from DEP:ROOT
        [ nsubj_nounchunks_from_root, nsubj_nounchunks_from_nonroot] = self.find_nounchunks_for_nsubj_nsubjpass_root()

        all =[]
        valid_agents = set()
        invalid_agents = set() #invalid_agents are kept to find possibility of other agents connected them by "of" (ie., "The probability of xxx" where invalid "probability" to find "xxx" )
        for ncs in nsubj_nounchunks_from_root:
            """
            ncs is a nounchunk so may contains DET(any, each, all, or the) so sperated with det and other part.
            For example, for "The ELMS", -> det = "The", agent_span = "ELMS"
            """
            [det, agent_span] = ArticleAgentParser.seperate_det_and_agent(ncs)
            in_both_term_nsubj = False
            if agent_span.lemma_ not in ArticleAgentParser.invalids:
                """compare with ncs with nounchunk recognized with term definition"""
                for tp, nct in term_definition_matched_span_dict.items():
                    if ncs == nct:  # term nc and nsubj nc are the same
                        # create agent exactly defined in term definition (i.e., "SLG")
                        all.append(ArticleAgentParser.createDetAgent(det, tp, [Confidence.Term,Confidence.DEP_NsubjNsubjpass_ROOT]))
                        valid_agents.add(tp)
                        if agent_span.text != tp.text:
                            # create agent with nounchunk without det (ie., "SLG Control System")
                            all.append(ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.Term,Confidence.DEP_NsubjNsubjpass_ROOT]))
                            valid_agents.add(agent_span)
                        in_both_term_nsubj = True
                        break #find for ncs matching nct                  
                # if ncs is not in term definition, then create Agent with just Confidence.DEP_NsubjNsubjpass_ROOT
                if in_both_term_nsubj == False: 
                    all.append( ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.DEP_NsubjNsubjpass_ROOT]))
                    valid_agents.add(agent_span)
            else:
                invalid_agents.add(agent_span)
  
        # find in term_definition_matched_span_dict only
        for tp, nct in term_definition_matched_span_dict.items():
            if tp not in valid_agents: #not found in nsubj/nsubjpass root
                det = None
                if nct != None and tp.text != nct.text:
                    [det, agent_span] = ArticleAgentParser.seperate_det_and_agent(nct)
                    if agent_span != tp: #if term definition and nounchunk is the same, not create new agent, because the agent is already created in above
                        if agent_span not in valid_agents:
                            all.append(ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.Term]))
                            valid_agents.add(agent_span)
                all.append(ArticleAgentParser.createDetAgent(det, tp, [Confidence.Term]))
                valid_agents.add(tp)

        if len(all) == 0:
            #if no agent is found.  Looking for two other ways(DEP_NsubjNsubjpass, Similar)
            for r in nsubj_nounchunks_from_nonroot:
                [det, agent_span] = ArticleAgentParser.seperate_det_and_agent(r)
                if agent_span.lemma_ not in ArticleAgentParser.invalids:
                    #create new agent with Confidence.DEP_NsubjNsubjpass and added to all
                    all.append(ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.DEP_NsubjNsubjpass]))
                    valid_agents.add(agent_span)  
                else:    
                    invalid_agents.add(agent_span)   

            # similar word from nsubj_from_nonroot
            similar_noun_chunks_with_nsubj_nounchunks_from_nonroot = self.find_similar_chunk(nsubj_nounchunks_from_nonroot, self._list_noun_chunks)
            for r in similar_noun_chunks_with_nsubj_nounchunks_from_nonroot:
                [det, agent_span] = ArticleAgentParser.seperate_det_and_agent(r)
                if agent_span.lemma_ not in ArticleAgentParser.invalids:
                    #create new agent with Confidence.Similar and added to all
                    all.append(ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.Similar]))
                    valid_agents.add(agent_span)
                else:
                    invalid_agents.add(agent_span)      

        # find more agent by looking at the found agents and invalid_agent_spans 
        valid_and_invalid_agents = valid_agents.union(invalid_agents)
        for agent_span in valid_and_invalid_agents:
            # finding nounchunk connected by of with the agent_span's root
            nc = ArticleAgentParser.find_nounchunks_connected_from_agent_root_with_of(agent_span.root, self._list_noun_chunks)
            # if the nounchunk exist find the root 
            if nc != None:
                # then seperate det and agent_span
                [det, agent_span] = ArticleAgentParser.seperate_det_and_agent(nc)
                if agent_span in valid_agents:
                    #add Confidence.Agent_of to the agent if already in all
                    ArticleAgentParser.addConfidenceToAgent(all, agent_span, Confidence.Agent_of)
                else:    
                    #add a new agent with the confidence    
                    all.append(ArticleAgentParser.createDetAgent(det, agent_span, [Confidence.Agent_of]))
  
        return self.modifyToConjElementIfRelevant(all)
    

    def find_nounchunks_for_nsubj_nsubjpass_root(self):
        """find list of Spans (spacy's noun_chunks) which has nsub or nsubjpass DEP but its POS is NOT "PRON(pronoun)" from ROOT or Non-ROOT token.

        Returns:
            [r1, r2]:
                r1 = spacy's noun_chunks span with nsub or nsubjpass DEP from ROOT
                r2 = spacy's noun_chunks span without nsub or nsubjpass DEP from ROOT
        """
        r1 = []
        r2 = []
        for chunk in self._list_noun_chunks:
            if chunk.root.dep_ in ["nsubj", "nsubjpass"] and chunk.root.pos_ != "PRON":
                if chunk.root.head.dep_ == "ROOT":
                    r1.append(chunk)
                else:
                    r2.append(chunk)
        return [r1, r2]


    def modifyToConjElementIfRelevant(self, alldetagents):
        """ check all DetAgents found so far and converted to AgentConj if necessary.
            There are two cases to create AgentConj.
            1) One DetAgent having "and" in Agent texts (ie., "The Door and door attachments")
               In this case two DetAgents(one with "The Door" and the other with "The door attachemnts") are created and one AgentConj is created from the two DetAgents.
            2) Multiple DetAgents with original text connected by "," and "and" (ie., "AA, BB, CC and DD" with four DetAgents["AA", "BB", "CC", "DD"]).
               In this case one AgentConj is created from the orignal DetAgents and new DetAgent by combining the DetAgents("AA, BB, CC, and "DD").

        Args:
            alldetagents (list of DetAgents): original detAgents to be checked

        Returns:
            list of (DetAgent or AgentConj): list of Agents found (DetAgent or AgentConj) 
        """
        
        return_detagents = []
        non_conj_agents = []
       
        for original_agent in alldetagents:
            #one agent (ie., Door and Door attachments) to create conjAgent
            and_tokens = [token for token in original_agent.getElements()[Agent].getTokens() if token.lemma_ == "and"]
            assert(len(and_tokens) <= 1) #not handling a case like "ABC and CDE and EFG" as agent.text
            if len(and_tokens) == 1:
                before = self._doc[original_agent.getElements()[Agent].getTokens().start: and_tokens[0].i]
                after = self._doc[and_tokens[0].i+1: original_agent.getElements()[Agent].getTokens().end]
                before_agent = ArticleAgentParser.createDetAgent(original_agent.getElements()[Article].getTokens(), before, original_agent.getElements()[Agent].getConfidences())
                after_agent = ArticleAgentParser.createDetAgent(original_agent.getElements()[Article].getTokens(), after, original_agent.getElements()[Agent].getConfidences())
                return_detagents.append(AgentsConj(and_tokens[0],[before_agent, after_agent, original_agent]))
            else:
                non_conj_agents.append(original_agent)

        if len(non_conj_agents) <= 1:
            return return_detagents + non_conj_agents
        else :
            # looking for a case having multiple agents connected by "," and "and" like "AA, BB, CC, and DD" to create one conjAgent and Agent with combined token(AA, BB, CC, and DD)
            for detagent in non_conj_agents:
                firstIndex =  detagent.getFirstIndex()
                if firstIndex != 0:
                    previousToken = self._doc[firstIndex-1] 
                    if previousToken.lemma_ == "and":
                        #finding last agent (ie., "DD" for "AA, BB, CC, and DD")
                        conj_agents =[]
                        conj_agents.append(detagent) # adding "DD"
                        #find remaining agents.  conj_agents = ["DD", "CC", "BB", "AA"].  The order is reversed.
                        conj_agents = ArticleAgentParser.allPreviousAgentsWithNextTokenComma(self._doc, non_conj_agents, firstIndex-2, conj_agents)
                        return_detagents.append(AgentsConj(previousToken,conj_agents))
                        #combine conj_agants to create new DetAgent
                        #combined agent since conj_agents is start with last agent to first agent in doc
                        combinedAgentSpan = self._doc[conj_agents[len(conj_agents)-1].getElements()[Agent].getTokens().start: conj_agents[0].getElements()[Agent].getTokens().end]
                        #combining confidences for conj_agents
                        combinedConfidences = set()
                        for detagent in conj_agents:
                            for c in detagent.getElements()[Agent].getConfidences():
                                combinedConfidences.add(c)
                        #create a detAgent
                        combined_agents = ArticleAgentParser.createDetAgent(conj_agents[len(conj_agents)-1].getElements()[Article].getTokens(), combinedAgentSpan, combinedConfidences)
                        #appanding the combined_agents
                        return_detagents.append(combined_agents)

        #finding any agent not included in conjAgent to be in non_conj_agents_not_in_return_detagents
        non_conj_agents_not_in_return_detagents =[]
        for agent in non_conj_agents:
            found = False
            for ragent in return_detagents:
                if isinstance(ragent, AgentsConj):
                    if agent in ragent.getElements():
                        found = True
            if found == False:
                non_conj_agents_not_in_return_detagents.append(agent)      

        return return_detagents + non_conj_agents_not_in_return_detagents

    # static method for DetAgentParser
    def allPreviousAgentsWithNextTokenComma(doc, detagents, index, listOfDetAgents):
        """recursively finding agents connected with ","

        Args:
            doc (spacy's Doc): doc for all tokens 
            detagents (list of DetAgent): DetAgents to find connected by ","
            index (int): doc's index suppposed to be ","
            listOfDetAgents (list of DetAgent): DetAgents connected by ",".  The order is reversed.  For example first DetAgents = ["AA", "BB", "CC", "DD"} from "AA, BB, CC and DD" text, returns ["CC", "BB", "AA"])

        Returns:
            list of DetAgent: listOfDetAgents
        """
        if index >= 1 and doc[index].text == ",":
            for detagent in detagents:
                if detagent.getElements()[Agent].getTokens().end == index:
                    listOfDetAgents.append(detagent)
                    listOfDetAgents = ArticleAgentParser.allPreviousAgentsWithNextTokenComma(doc, detagents, detagent.getElements()[Agent].getTokens().start-1, listOfDetAgents)
        return listOfDetAgents

    @staticmethod
    def addConfidenceToAgent(all, agentspan, confidence):
        """ adding Confidence to an Agent element
            by finding the Agent element from all( list of DetAgent) based on agentspan
        Args:
            all (list[DetAgent]): list containing DetAgent
            agentspan (Spacy's span): agentspan looking for
            confidence (Confidence): confidence to add
        """
        for detagent in all:
            agent = detagent.getElements()[Agent]
            if agent.getTokens() == agentspan:
                agent.addConfidence(confidence)

    @staticmethod
    def seperate_det_and_agent(span):
        """seperate span into det and agent

        Args:
            span (Span): to be checked

        Returns:
            list:if the chunk[0].pos_ == "DET" return [det token, remaining span], otherwise return [None, span]
        """
        if span[0].pos_ == "DET":
            return [span[0], span[1:]]
        else:
            return [None, span]

    @staticmethod
    def createDetAgent(agent_det_token, agent_span, agent_confidences):
        """_summary_

        Args:
            agent_det_token (Token): det for agent
            agent_span (Span): agent span
            agent_confidences (list[confidence]): list of confidences

        Returns:
            DetAgent: DetAgent created from inputs
        """

        """find if the agent_span is fit or not"""
        fit = not (agent_span.lemma_ in ArticleAgentParser.unfits)
        agent = Agent(agent_span, agent_confidences, fit)

        # last token in agent_noun_chunk
        # plural - #https://cs.nyu.edu/~grishman/jet/guide/PennPOS.html NNS = Noun, plural, NNPS = Proper noun, plural
        if agent_span[len(agent_span) - 1].tag_ in ["NNS", "NNPS"] and (
            # not in Term Definition
            Confidence.Term not in agent_confidences
            # or in Term Definition but not all uppercase like "ASCS"
            or (
                Confidence.Term in agent_confidences
                and (agent_span.text != agent_span.text.upper())
            )
        ):
            # agent is plural
            return ArticleAgent(Article(agent_det_token, [Enum_Article.Any, Enum_Article.Each]), agent)
        else:  # agent is not plural
            if agent_det_token == None or agent_det_token.text.lower() == "the":
                return ArticleAgent(Article(agent_det_token, [Enum_Article.The]), agent)
            else:  # Each or Any
                return ArticleAgent(
                    Article(agent_det_token, [Enum_Article.Any, Enum_Article.Each]), agent
                )

    @staticmethod
    def find_similar_chunk(span_similar_to, list_noun_chunks):
        """find spans similar to 'span_similar_to' from list of nounchunks.
           consider similar if both span's root text are the same.

        Args:
            span_similar_to (sapn): span similar to this wants to find
            list_noun_chunks (_type_): list of spacy's nounchunks in this line

        Returns:
            list[Span]: spans similar to span_similar_to
        """
        r1 = []
        # for chunk in doc.noun_chunks:
        for chunk in list_noun_chunks:
            if not (chunk in span_similar_to):  # if not is the same chunk
                if chunk.root.text in [rchunk.root.text for rchunk in span_similar_to]:
                    r1.append(chunk)
        return r1

    @staticmethod  
    def find_nounchunks_connected_from_agent_root_with_of(agent_chunk_root, list_noun_chunks):
        """Find nounchunks connected with prep("of") from an agent chunk root.
        For example, The failure of the circuit breaker .....
        with "failure" as agent_chunk_root, "the circuit broker" noun_chunk is returned.
        "failure" -> dep:pref -> "of" -> dep:pobj -> broker and nounchunk containing "broker" is "the circuit broker"
        Args:
            agent_chunk_root (Spacy's token): used to find pobj connected with "of" to this token
            list_noun_chunks (_type_): noun_chunks for this sentence/requirement.

        Returns:
            Spacy's span: noun_chunk found, or None if not found
        """
        #find pobj tokens from agent_chunk_root with "of"
        pobj_tokens = ArticleAgentParser.get_prep_pobj(agent_chunk_root, "of") 
       
        for pobj in pobj_tokens:
            for noun_chunk in list_noun_chunks:
                if noun_chunk.root == pobj:
                    return noun_chunk
          
        return None

    @staticmethod
    def get_prep_pobj(pobjs_token, prep_lemma):
        """Find pobjs connecting by of(s) from pobj_token
           (ie., The failure of the circuit breaker .....
            try to find "broker" token from token = "probability" and prep_lemma = "of"
            When there are multiple of 
            The probability of loss of HSTA trim capability...
            find "capability" token from token = "probability" and prep_lemma ="of"

        Args:
            token (Spacy's Token): base token ("failure") to find another token ("breaker") connected with prep_lemma
            prep_lemma (String): prep lemma that looking for 

        Returns:
            list[Spacy's token]: pobj tokens connected by prep_lemmea.  Empty list is returned if not found
        """
        right_tokens = pobjs_token.rights #rights of token
        r_pobj_tokens = []
        for right_token in right_tokens:
            if right_token.dep_ == "prep":  # "of" and right.lemma_ == prep_lemma:
                   if right_token.lemma_ == prep_lemma:  # only for "of"
                    #finding right_token("of") or right tokens that have DEP="pobj"
                    pobj_tokens = [r for r in right_token.rights if r.dep_ == "pobj"]  # ["breaker"]
                    if len(pobj_tokens) == 0:
                        return [] #not found
                    for pobjs_token in pobj_tokens:
                        #in case having multiple prep_lemma ("of")
                        rs = ArticleAgentParser.get_prep_pobj(pobjs_token, prep_lemma)  
                        #if two pref("of") 
                        if len(rs) == 0:
                            r_pobj_tokens.append(pobjs_token)
                        else: #just one prep("of")
                            r_pobj_tokens.extend(rs)  
        return r_pobj_tokens


    def info(self):
        """return text representation for the identified elements """
        return [a.info() for a in self._agents]