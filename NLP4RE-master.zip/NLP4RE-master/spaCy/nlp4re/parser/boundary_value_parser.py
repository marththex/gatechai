from nlp4re.elements.boundary_value_conj import BoundaryValueConj
from nlp4re.spacy_config import nlp
from nlp4re.utils.util import find_nounchunks_for_matcher
from nlp4re.elements.boundary_value import BoundaryValue
from nlp4re.elements.boundary_value_conj import BoundaryValueConj
from nlp4re.elements.boundary import Boundary
from nlp4re.elements.value import Value
from nlp4re.elements.element import Confidence
from nlp4re.parser.element_parser import ElementParser
from dataclasses import dataclass, field


@dataclass
class BoundaryValueParser(ElementParser):
    _boundary_and_values: list[BoundaryValue] or list[BoundaryValueConj] = field(
        default_factory=list
    )

    def process(self):

        """
        Spacy matchar created from term definition excel for Boundary (tab = Boundary, columns = Name, Acronym, Aliases)
        """
        matches_b = BoundaryValueParser.b_term_matcher(self._doc)
        """
            Spacy matcher created from term definiction excel for Value (tab = Value, columns = Name, Acronym, Aliases, Units)
            currently not used for extracting.
        """
        matches_v = BoundaryValueParser.v_term_matcher(self._doc)

        default_boundary = Boundary([], [Confidence.Term], ["equal to"])  # Default boundary is set to "equal to"

        value_list = []  # List to hold all the Values objects in the _doc
        boundary_idx_list = []  # List to hold all the assumed boundary indices.

        for matchId, start_idx_v, end_idx_v in matches_v:  # loop iterates over the matches found in excel file for
            # the value (unit) in the _doc and retrieves start and end indices.
            if "°" in str(self._doc[start_idx_v - 1:end_idx_v]):  # condition checks to make sure if ° unit is inbetween
                value_list.append(Value(self._doc[start_idx_v - 2:end_idx_v], [Confidence.Term_Unit]))
                # appending Value object with start index - 2 till end index.
                # This is done in order to get the actual value from the _doc
                boundary_idx_list.append(start_idx_v - 3)  # assuming start index - 3 to be the boundary.
            else:
                value_list.append(Value(self._doc[start_idx_v - 1:end_idx_v], [Confidence.Term_Unit]))
                # appending Value object with start index - 1 till end index.
                # This is done in order to get the actual value from the _doc
                boundary_idx_list.append(start_idx_v - 2)  # assuming start index - 2 to be the boundary.
        # Length of value_list = length of boundary_idx_list
        boundary_list = []  # List to hold all the Boundary objects in the _doc.
        # If no Boundary in doc, a default will be assigned.
        is_prev_between = False  # Flag to check if previous index in the loop was Between or from
        for ind in boundary_idx_list:
            no_boundary = True  # Flag to check if there is boundary in the _doc. Defaulting to True.
            for matchId, start_idx_b, end_idx_b in matches_b:
                if start_idx_b <= ind <= end_idx_b:  # Checking if assumed boundary is actually a recognised boundary
                    # from Excel sheet.
                    if str(self._doc[ind:ind + 1]) in ["between", "from"]:  # Checking if boundary is Between or from
                        boundary_list.append(("and", Boundary([], [Confidence.Term], "greater than")))
                        is_prev_between = True
                    # elif str(self._doc[ind:ind + 1]) in ["range of", "to"]:  # Checking if boundary is Between or from
                    #     boundary_list.append(("and", Boundary([], [Confidence.Term], "greater than")))
                    #     is_prev_between = True
                    else:
                        boundary_list.append(("", Boundary(self._doc[start_idx_b:end_idx_b], [Confidence.Term])))
                    no_boundary = False
                    break
                elif is_prev_between:  # If previous index was between, then the next boundary is auto assigned
                    # and flag is set to False
                    boundary_list.append(("and", Boundary([], [Confidence.Term], "less than")))
                    is_prev_between = False
                    no_boundary = False
                    break
            if no_boundary:  # If there was no boundary, then setting to default boundary
                if str(self._doc[ind - 2:ind - 1]) in ["between", "from", "of"]:
                    boundary_list.append(("and", Boundary([], [Confidence.Term], "less than")))
                    boundary_list.append(("and", Boundary([], [Confidence.Term], "greater than")))
                    value_list.insert(ind, Value(self._doc[ind - 1:ind], [Confidence.Term_Unit]))
                else:
                    boundary_list.append(("", default_boundary))

        is_first_and = False  # Flag to check if this is a conjoint Boundary value.
        # If the tuple in the list created earlier for Boundary contains "and" then it is conjoint.
        for i in range(len(value_list)):
            if boundary_list[i][0] == "and" and not is_first_and:
                self._boundary_and_values.append(
                    BoundaryValueConj([nlp("and")], [BoundaryValue(boundary_list[i][1], value_list[i]),
                                                     BoundaryValue(boundary_list[i + 1][1], value_list[i + 1])]))
                # Both the value of Conjoint is added to _boundary_and_values as above
                is_first_and = True  # Flag is set to Ture as the first of the conjoint BV is found.
            elif boundary_list[i][0] == "and":
                is_first_and = False  # For the second "and", we return the Flag to False.
                # This is done in case there are more conjoins in the _doc
            else:
                self._boundary_and_values.append(
                    BoundaryValue(boundary_list[i][1], value_list[i]))

        return self._boundary_and_values

    def modifyToConjElementIfRelevant(self):

        """Combine more than one BoundaryValue elements into BoundaryValueConj element if relevant
        For example,
            with "more than 1 and less than 3" original text,
            boundary_value_parser.process() return two BondaryValue elements
            One with Boundary._text = "more than" and Value._text = 1
            The other with Boundary._text = "less than" and Value._text = 3
            In this case, BoundaryValueConj element should be created with BoundaryValueConj._conj = "and" token
            and BoundaryValueConj._elements = two BoundaryValue elements returned from boundary_value_parser.process()
            then put in self._elements.
        If  boundary_value_parser.process() returns only one BoundaryValue, just put the BoundaryValue in self._elements.
        if  boundary_value.boundary_value_parser.process() returns three BoundaryValue elements from text "... 3.1 psi ......more than 1 kg and less than 3 kg",
            then the first BoundaryValue(3.1 psi) is not related to the other two BoundaryValue elements, so just add to the first BouondaryValue in self._elements,
            and create BoundaryValueConj elements from and put in self._elements

        Currntly BoundaryValueConj._expand = False with default.
        I am not sure for "... 3.1 psi ......more than 1 kg and less than 3 kg", need to exapnded to two requirements
        one with .... 3.1 psi
        the other with  ...more than 1 kg and less than 3 kg
        We should hand when we enconter the such kind of requirement.
        If "... 3.1 psi and more than 1 kg and less than 3 kg", the three BoundaryValue returned from boundary_value_parser.process(), may need create a BoundaryValueConj
        with with BoundaryValueConj( conj ="and" token,
        elements = [BoundaryValue(3.1 psi),
                    BoundaryValueConj(conj = "and" token, elements = [BoundaryValue( more than 1 kg), BoundaryValue( less than 3 kg)])
                    ]
        )
        """

    def info(self):
        return [c.info() for c in self._boundary_and_values]
