import spacy
from spacy import displacy, tokens
from spacy.tokens import Token
from nlp4re.utils.util import *
from nlp4re.utils.matcher_terms import *
from nlp4re.elements.characteristic import *
from nlp4re.elements.element import Confidence
from nlp4re.parser.element_parser import ElementParser
from dataclasses import dataclass, field
from typing import List


@dataclass
class CharacteristicParser(ElementParser):

    characteristics: List[Characteristic] = field(default_factory=list)
    _characteristics: List[Characteristic] = field(default_factory=list)
    temp_used_noun_chunk_list = set()
    patterns_dict = get_pattern_dict()

    def process(self):
        """
        Required method for processing a single line of text.  Creates `Characteristic` objects,
        assigned to `self._characteristics`, and returns them.
        """
        # Term defintions
        dict_term = {}
        # Characteristic
        found = find_nounchunks_for_matcher(
            self._doc, CharacteristicParser.c_term_matcher, self._line, self._list_noun_chunks
        )
        r1 = found.keys()

        for r in r1:
            if r not in dict_term.keys():
                if len(to_lemma_text_set(r) & set(CharacteristicParser.c_invalids)) == 0:
                    dict_term[r] = Characteristic(r, [Confidence.Term])
                else:
                    print("Invalid: " + r)

        noun_chunk_before_2gram_dep = {}
        for chunk in self._list_noun_chunks:
            if chunk.root.dep_ in ["nsubj","nsubjpass"]: # ABORT on AGENT chunks (active/passive subj of root verb)
                continue

            head = chunk.root.head #1st # word preceding ROOT of noun-chunk
            if head.head != None:
                #if head.dep_ != "ROOT" and head.head != None: #2nd
                if chunk.root.dep_ in ["dobj"]:
                    self._characteristics.append(Characteristic(chunk,[Confidence.Pattern_DEP_after]))
                    self.temp_used_noun_chunk_list.add(chunk)
                    continue
                if head.dep_ == "ROOT": #head and head.head is the same
                    key = head.lemma_ # with
                else:    
                    key = head.head.lemma_ + " " + head.lemma_ # as in 'exposure to'
                if key in noun_chunk_before_2gram_dep:
                    noun_chunk_before_2gram_dep[key].append(chunk)
                else:    
                    noun_chunk_before_2gram_dep[key] = [chunk]    #i.e, exposure to

        if (len(noun_chunk_before_2gram_dep) != 0 ):
            for after in CharacteristicParser.c_afters:
                if after in noun_chunk_before_2gram_dep:
                    for v in noun_chunk_before_2gram_dep[after]:
                        if len(to_lemma_text_set(v) & set(self.c_invalids)) == 0:
                            # if in term definition then replace confidence from 0.9 to 1 and appending method with & After
                            if v in dict_term.keys():
                                cv = dict_term[v]
                                cv.confidence = 1
                                cv.method += " & After"
                            else:  #assume no same condition is with more than one after keywords (ie., A is expose to B and exposure to B)  
                                self._characteristics.append(Characteristic(v, [Confidence.Pattern_of]))
                            self.temp_used_noun_chunk_list.add(v)

        element_noun_chunks, used_noun_chunks = find_pattern_matching_chunk(noun_chunk_before_2gram_dep,
            dict_term, self.patterns_dict["CHARACTERISTIC"], self.c_invalids, "After")
        for i in range(len(element_noun_chunks)):
            self._characteristics.append(Characteristic(element_noun_chunks[i], [Confidence.Match]))
            self.temp_used_noun_chunk_list.add(used_noun_chunks[i])
        for v in dict_term.values():
            self._characteristics.append(v)

        return self._characteristics



    # def processOld(self):
    #     """Parse the stored document

    #     Identify words/phrases that are likely characteristics in the input text.
    #     Step 1: Find all noun chunks.
    #     Step 2: Select terms in the found phrases that are listed in the given term definitions. (confidence=0.9)
    #     Step 3: Evaluate remaining noun chunks and exclude the agent (dependency target of type "nsubj" or "nsubjpass").
    #     Step 4: Evaluate remaining phrases and immediately accept those that are dependency target(s) of type "dobj".
    #     Step 5: Evalute remaining and accept those that match given characteristic patterns (confidence=0.8)
    #     """
    #     self.temp_used_noun_chunk_list = set() #reset
    #     [c_matcher, dict_terms, self.c_invalids] = [self.c_term_matcher, self.c_dict_terms, []]
    #     r2, remove = self.find_nounchunk_contains_terms(self._doc, c_matcher, self._line)
    #     self.temp_used_noun_chunk_list.update(remove)
    #     for rr in r2:
    #         if rr not in dict_terms.keys():
    #             dict_terms[rr] = Characteristic(rr, 0.9, "Characteristic")

    #     noun_chunk_before_2gram_dep = {}
    #     for chunk in self._list_noun_chunks: #n is span
    #         # ABORT if chunk passes the AGENT test (is active/passive subj of root verb)
    #         if chunk.root.dep_ in ["nsubj","nsubjpass"]:
    #             continue

    #         head = chunk.root.head #1st # word preceding ROOT of noun-chunk
    #         if head.head != None:
    #             #if head.dep_ != "ROOT" and head.head != None: #2nd
    #             if chunk.root.dep_ in ["dobj"]:
    #                 self.characteristics.append(Characteristic(chunk,0.7,chunk.root.dep))
    #                 self.temp_used_noun_chunk_list.add(chunk)
    #                 continue
    #             if head.dep_ == "ROOT": #head and head.head is the same
    #                 key = head.lemma_ # with
    #             else:    
    #                 key = head.head.lemma_ + " " + head.lemma_ # as in 'exposure to'
    #             if key in noun_chunk_before_2gram_dep:
    #                 noun_chunk_before_2gram_dep[key].append(chunk)
    #             else:    
    #                 noun_chunk_before_2gram_dep[key] = [chunk]    #i.e, exposure to

    #     if (len(noun_chunk_before_2gram_dep) != 0 ):
    #         for after in CharacteristicParser.c_afters:
    #             if after in noun_chunk_before_2gram_dep:
    #                 for v in noun_chunk_before_2gram_dep[after]:
    #                     if len(to_lemma_text_set(v) & set(self.c_invalids)) == 0:
    #                         # if in term definition then replace confidence from 0.9 to 1 and appending method with & After
    #                         if v in dict_terms.keys():
    #                             cv = dict_terms[v]
    #                             cv.confidence = 1
    #                             cv.method += " & After"
    #                         else:  #assume no same condition is with more than one after keywords (ie., A is expose to B and exposure to B)  
    #                             self.characteristics.append(Characteristic(v, 0.8, "After"))
    #                         self.temp_used_noun_chunk_list.add(v)

    #     element_noun_chunks, used_noun_chunks = find_pattern_matching_chunk(noun_chunk_before_2gram_dep,
    #         dict_terms, self.patterns_dict["CHARACTERISTIC"], self.c_invalids, "After")
    #     for i in range(len(element_noun_chunks)):
    #         self.characteristics.append(Characteristic(element_noun_chunks[i], 0.8, "After"))
    #         self.temp_used_noun_chunk_list.add(used_noun_chunks[i])

    #     #for v in dict_terms.values():
    #     #    self.characteristics.append(v)
    #     for c in self.characteristics:
    #         c.setTexts()
    #     self.remove_lst_noun_chunks(self.temp_used_noun_chunk_list)
    #     return self.characteristics

    # def find_nounchunk_contains_terms(self, doc, matcher, line):
    #     """Find all noun chunks containing any of the given input strings.
    #     Args:
    #         doc (Doc): The trained 
    #         matcher ([type]): [description]
    #         line ([type]): [description]
    #     Returns:  Tuple consisting of
    #         [str]: List of TermDef noun chunks matched in the current sentence
    #         [str]: List noun chunks NOT matching any TermDef entries.
    #     """        
    #     r = []
    #     """List of TermDef noun chunks matched in the current sentence"""
    #     remove_noun_chunks_list = []
    #     """List of spaCy-returned noun chunks NOT exact-matched (case insensitive) in TermDefs."""

    #     # line2 = get_singular_noun_root_line(nlp, line, doc) #line2 is lemma version of line
    #     line2 = get_singular_noun_root_line(doc) #line2 is lemma version of line
    #     doc2 = nlp(line2)
    #     assert(len(doc) == len(doc2)) #maybe remove later
    #     matches = matcher(doc2)
    #     for match_id, start, end in matches:
    #         term_span = doc2[start:end] #match_id_string = nlp.vocab.strings[match_id] = OBJECT
    #         for chunk in self.lst_noun_chunks:
    #             #if chunk[0].pos_ =="DET" and  doc2[chunk.start+1: chunk.end] == term_span:
    #             if chunk[0].pos_ =="DET" and  is_noun_chunk_the_same(doc2[chunk.start+1: chunk.end],term_span):
    #                 assert(doc[chunk.start:chunk.end].text.startswith(chunk.text))
    #                 r.append(chunk)
    #                 remove_noun_chunks_list.append(chunk)
    #                 break
    #             #elif term_span.text == chunk.text  #comparing lemma chunk with team (term_span text)
    #             elif is_noun_chunk_the_same(term_span, chunk):
    #                 assert(doc[chunk.start:chunk.end].text.startswith(chunk.text))
    #                 r.append(chunk)
    #                 remove_noun_chunks_list.append(chunk)
    #                 break
    #             elif (term_span.start >= chunk.start) and (term_span.end <= chunk.end): #a term is contained in a part of noun_chunk
    #                 #assert(doc[chunk.start:chunk.end].text.startswith(chunk.text)) data vs. datum
    #                 #print(doc[chunk.start:chunk.end].text)
    #                 #print(chunk.text)
    #                 #Do I need add this?????? - r.append(doc[start:end]) #put term_span(doc2/lin2) based on doc/line (ie., paragraph)
    #                 #change from
    #                 #r.append(doc[chunk.start:chunk.end]) #put chunk(doc2/line) but based on doc/line (ie., paragraph 3.3.5.2.1)
    #                 #to below because chunk created with doc[chunk.start:chunk.end] have label 0, where chunk has a lable like 3342607623747562680
    #                 r.append(chunk)
    #                 remove_noun_chunks_list.append(chunk)
    #                 break
    #         if len(r) == 0: # not in noun_chunk but in TermDef (ie., SECTION's "Table 5-1" is not a noun-chunk => Table(Noun), 5-(NUM), 1(NUM))
    #             non_noun_chunk_span = doc[start:end]
    #             r.append(non_noun_chunk_span) 

    #     return r, remove_noun_chunks_list

    # def remove_lst_noun_chunks(self, remove_list:str):
    #     """Record token assignment status for noun chunks.
    #     Purge noun chunks assigned to this BP element from the list of those still
    #     available in the current sentence, effectively tagging them as used.  All
    #     elements in the input list are purged from the current list of availables:
    #         `self.lst_noun_chunks`,

    #     Args:
    #         remove_list ([str]): noun chunks to be marked as used and unavailable for future matching
    #     """
    #     for r in remove_list:
    #         self._list_noun_chunks.remove(r)


    # def print(self):
    #     """Print current object and data.

    #     Generate a string representation of this object and print it to the standard output stream.
    #     """
    #     print(f"{self.line_number}: ", end = "")
    #     print( [c.texts for c in self._characteristics])

    def info(self):
        """return text representation for the identified elements """
        return [c.info() for c in self._characteristics]
