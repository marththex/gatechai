from abc import abstractmethod
from typing import Any
from dataclasses import dataclass
from spacy.tokens import Doc
from spacy.tokens import Span
from nlp4re.utils.util import *

@dataclass
class ElementParser:
    """Abstract class for all element-specific parsers.
        Parsers produce (specific) `Element`s from raw text input.
       
    Fields:
        line (str): a line of requirement text
        doc (spacy.tokens.Doc): parsed Doc from the requirement text
        line_number (int): line_number if multiple lines of requirement are parsed.
        list_noun_chunks (list[spacy.tokens.Span]): spacy.noun_chunks for the line

    """

    _line: str
    _doc: Doc
    _line_number: int
    _list_noun_chunks: list[Span]

    def getDoc(self):
        """
        Return spacy's doc: return pased spacy's doc
        """
        return self._doc

    @abstractmethod
    def process(self):
        """
        This function must be implemented by subclasses that return list of identified Elements
        """
        pass

    @abstractmethod
    def info(self):
        """
        This function must be implemented by subclasses that print information about identified elements
        """
        pass

