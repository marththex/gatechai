from typing import List
from nlp4re.utils.util import to_lemma_text_set, find_nounchunks_for_matcher
from nlp4re.parser.element_parser import ElementParser
from nlp4re.elements.element import Confidence
from nlp4re.elements.event import Event
from dataclasses import dataclass, field



@dataclass
class EventParser(ElementParser):
    """ Parser class for parsing a line of text and creating Event Element
        Subclass of an abstract ElementParser

        Parameters:
            _event: (list of Condition_Event) : The single element identified by this parser
    """    
    _event: List[Event] = field(default_factory=list)

    def process(self):
        """  
        required method which process a line of text, create Condition_Event objects,
        assigned to self._event and return them.

        Returns:
            List[Condition_Event]: identified elements
        """

        # 1. Finding elements with Confidence.Term
        #dict key= span value = ConditionEvent
        condition_event_dict_term = {}
        #dict key = span, value = noun-chunk containing the span.  This is used to match ConditionEvent identified using Confidence.Term with nounchunk found using Confidence.Pattern_DEP_after
        map_span_to_nounchunk = {}
        # 1.2 Event   
        found = find_nounchunks_for_matcher( self._doc, EventParser.e_term_matcher, self._line, self._list_noun_chunks)
        r2 = found.keys()
        # term words vs. noun-chunks
        #lighting vs. lighting, 
        # EMV vs. EMI, 
        # lightning vs. lightning strike, 
        # lighting strike vs. lighting strike, 
        # hail ground vs. grand hail
        # fire and wheel threads vs. same
        # Ultimate accerelation loads vs. the same, 
        # lightning vs. a 1,300 volt peak lightning pulse, 
        # lightning vs. a lightning strike
        # lightning vs. direct lightning attachment, 
        # lightning vs. HIRF/lightning, 
        # EMI vs. EMI/lightning environment conditions
        for rr in r2:
            if rr not in condition_event_dict_term.keys(): #if not alredy in the list
                #if not invalid put in the list with Confidence.Term
                if (len(to_lemma_text_set(rr) & set(EventParser.e_invalids)) == 0 ):
                    condition_event_dict_term[rr] = Event(rr, [Confidence.Term]) 
                    map_span_to_nounchunk[rr] = found.get(rr)

    
        # 2 Finding Condition/Event with Confidence.Pattern_DEP_after
        # 2-1 Finding Condition_Event from Pattern.xlsx - After column words
        #key = string (2 tokens before the noun-chunk), value= noun-chunk
        #For example for "The slide/raft shall be capable of withstanding exposure to salt spray.
        #    {of withstand [exposure],  exposure to [salt spray]}
        noun_chunk_before_2gram_dep = {} 
       
        # 2-1-1 searching possibility from noun_chunks of the line and put in noun_chunk_before_2gram_dep
        for noun_chunk in self._list_noun_chunks:  # n is span
             # since noun_chunk.root.dep_ is nsubj or npasssubj is not likely to be condition, so ignored
            if noun_chunk.root.dep_ in ["nsubj", "nsubjpass"]:
                continue #ignored

            assert(noun_chunk.root.head.head != None)
            #head = noun_chunk.root.head  # 1st
            if noun_chunk.root.head.head != None:
                # if head.dep_ != "ROOT" and head.head != None: #2nd
                if noun_chunk.root.head.dep_ == "ROOT":  # head and head.head is the same
                    key = noun_chunk.root.head.lemma_
                else:
                    key = noun_chunk.root.head.head.lemma_ + " " + noun_chunk.root.head.lemma_ #ie., exposure to
                if key in noun_chunk_before_2gram_dep:
                    noun_chunk_before_2gram_dep[key].append(noun_chunk)
                else:
                    noun_chunk_before_2gram_dep[key] = [noun_chunk]  # i.e, key(2 tokens in string before the noun-chuk) = "expose to", value(noun-chunk) = "a humid environment"

        # 2-1-2 From noun_chunk_before_2gram_dep, match with Patterns.xlsx's after column words
        if len(noun_chunk_before_2gram_dep) != 0:
            for after in EventParser.c_afters:
                if after in noun_chunk_before_2gram_dep:
                    for nchunk in noun_chunk_before_2gram_dep[after]: 
                        if (len(to_lemma_text_set(nchunk)& set(EventParser.e_invalids)) == 0):  # if invalid, then length != 0
                            keys = self.getDictKeys(map_span_to_nounchunk, nchunk) #check if the nchunk is already found (in condition_event_dict_term)
                            if len(keys) == 0:
                                #create Condition_Event and add in self._event. 
                                self._event.append(Event(nchunk, [Confidence.Pattern_DEP_after]))
                            #existing already with Confidence = Term so add Confidence.Pattern_DEP_after
                            for key in keys:
                                cv = condition_event_dict_term[key]
                                cv.addConfidence(Confidence.Pattern_DEP_after)
                            
        # adding condition_event found with Confidence.Term to self._event
        for condition_event in condition_event_dict_term.values():
            self._event.append(condition_event)

        return self._event

    
    def getDictKeys(self, map_span_to_nounchunk, nounchunk):
        """if map_span_to_nounchunk.value = nounchunk, then collect map_span_to_nounchunk keys and return

        Args:
            map_span_to_nounchunk (Dict): dictonary key = term defintion phrase, value = the nounchunk span containing the key
            nounchunk (span): string try to match with map_span_to_nounchunk.value

        Returns:
            List(string): list of term definition phrases contained in the nounchunk.text
        """
        keys = []
        for key, value in map_span_to_nounchunk.items():
            #comparing k == v return false even its text matches, because they are different span object.  Thus same or not by comparing their start and end values.
            if value.start == nounchunk.start and value.end == nounchunk.end: 
                keys.append(key)
        return keys

    def info(self):
        """return text representation for the identified elements """
        return [condition_event.info() for condition_event in self._event]
