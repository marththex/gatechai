from nlp4re.utils.util import to_lemma_text_set, find_nounchunks_for_matcher
from nlp4re.parser.element_parser import ElementParser
from nlp4re.elements.element import Confidence
from nlp4re.elements.object import Object
from dataclasses import dataclass, field


@dataclass
class ObjectParser(ElementParser):
    """
    A parser class to extract State objects from spacy's parsed doc (self._doc)
    """

    _objects: list[Object] = field(default_factory=list)

    def process(self):
        """
        required method which process a line of text, create State objects, assigned to self._states and return them.
        """
        # Term defintions
        dict_term = {}
        # State
        found = find_nounchunks_for_matcher(
            self._doc, ObjectParser.o_term_matcher, self._line, self._list_noun_chunks
        )
        r1 = found.keys()

        for r in r1:
            if r not in dict_term.keys():
                if len(to_lemma_text_set(r) & set(ObjectParser.invalids)) == 0:
                    dict_term[r] = Object(r, [Confidence.Term])
                else:
                    print("Invalid: " + r)

        for v in dict_term.values():
            self._objects.append(v)

        return self._objects

    def info(self):
        """return text representation for the identified elements """
        return [s.info() for s in self._states]
