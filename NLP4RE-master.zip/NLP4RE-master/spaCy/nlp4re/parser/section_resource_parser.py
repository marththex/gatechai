from nlp4re.elements.section_resource import SectionResource
from nlp4re.elements.element import Confidence, Element
from nlp4re.elements.section import Section
from nlp4re.elements.resource import Resource
from nlp4re.elements.section_resources_conj import SectionResourcesConj
from nlp4re.parser.element_parser import ElementParser
from dataclasses import dataclass, field


@dataclass
class SectionResourceParser(ElementParser):
    """ Parser class for parsing a line of text and creating Section and Resource Elements
        Subclass of an abstract ElementParser

        Parameters:
            _sections_and_resources (list) : The list contains SectionResource or SectionResourceConj objects. The grouped element identified by this parser.
            _validDET (list of string): Section and Resource sometimes precede with. (ie., "This section")
    """
    _sections_and_resources: list[Element] = field(default_factory=list)
    _validPrecede = ["this"]

    def process(self):
        """  
        required method which process a line of text, create SectionResource objects, assigned to self._sections_and_resources, and return them.
        
        Returns:
            List[ArticleAgent]: identified elements
        """
        slist = [] # span list for sections find based on startswith
        rlist = [] # span list for resources find based on startswith
        nextIndex_s = 0  # used to skip tokens
        nextIndex_r = 0
        for i in range(len(self._doc)):
            token = self._doc[i]
            # filter starting tokens for Section or Resource (ie., "D6-" is NUM, "ASCS" and "ASCS1111" are "PROPN")
            if token.pos_ == "PROPN" or token.pos_ == "NOUN" or token.pos_ == "NUM":
                # finding section comparing "StartsWith" column of Patterns.xlsx and not in invalids defined in Term_Definition.xlsx
                if nextIndex_s <= i and is_startswith_in_keywords(
                    token, SectionResourceParser.s_startwith
                ):
                    if not isTokenInNounChunksAndNsubj(token, self._list_noun_chunks): #avoid token with nsubj/nsubjpass because they are likely to be agents
                        span = findSpan(
                            token,
                            SectionResourceParser.s_startwith,
                            self._doc,
                            SectionResourceParser.s_invalids,
                        )
                        if span != None:  # only None if the span text in in invalids
                            slist.append(span)
                            nextIndex_s = span.end
                else:
                    nextIndex_s += 1
                # finding resource comparing "StartsWith" column of Patterns.xlsx and not in invalids defined in Term_Definition.xlsx
                if nextIndex_r <= i and is_startswith_in_keywords(
                    token, SectionResourceParser.r_startwith
                ):
                    if not isTokenInNounChunksAndNsubj(token, self._list_noun_chunks): #avoid token with nsubj/nsubjpass because they are likely to be agents
                        span = findSpan(
                            token,
                            SectionResourceParser.r_startwith,
                            self._doc,
                            SectionResourceParser.r_invalids,
                        )
                        if span != None:  # only None if the span text is in invalids
                            rlist.append(span)
                            nextIndex_r = span.end
                else:
                    nextIndex_r += 1

        k = {"SECTION": slist, "RESOURCE": rlist}
        
        #find Section using Term Defintion.xlsx
        st = findByTermDefinition(
            self._doc,
            SectionResourceParser.s_term_matcher,
            SectionResourceParser.s_invalids,
        )
        #find Resource using Term Definition.xlsx
        rt = findByTermDefinition(
            self._doc,
            SectionResourceParser.r_term_matcher,
            SectionResourceParser.r_invalids,
        )
        t = {"SECTION": st, "RESOURCE": rt}

        #merging section and resource list found based on Patterns.xlsx and Term Definition.xlsx
        if len(st) != 0 or len(rt) != 0 or len(slist) != 0 or len(rlist) != 0:
            self._sections_and_resources = self.mergeSpanFromKeywordAndTermDefinition(
                k, t
            )
        #modify the SectionResource to SectionResourcesConj if necessary
        self.modifyToConjElementIfRelevant()
        return self._sections_and_resources

    def modifyToConjElementIfRelevant(self):
        """ modify the SectionResource to SectionResourcesConj if necessary.
            Only convert to SectionResourceConj if a token between two SectionResources is "and".
        """

        #if length is less than 1 than not possible to be conj element
        if len(self._sections_and_resources) <= 1:
            return
        elif ( #only supporting for # of SectionResources found is 2
            len(self._sections_and_resources) == 2
        ):  # only supporting [Section0 of] Resource0 and [Section1 of ]Resouce1  - both Resource must exists
            # finding token between 2 SectionResource
            [start1, end1] = self._sections_and_resources[
                0
            ].getStartEndIndex()  # getStartEndIndex in SectionResource
            [start2, end2] = self._sections_and_resources[1].getStartEndIndex()

            if (
                start1 == None or end1 == None or start2 == None or end2 == None
            ):  # this happens one of elements is implied element (no tokens)
                return  # not ConjElement

            token_between = None
            if end1 + 1 == start2:
                token_between = self._doc[end1]
            elif end2 + 1 == start1:
                token_between = self._doc[end2]

            #convert to Conj element if the following is true
            if (
                token_between != None
                and token_between.lemma_ == "and"
                and token_between.pos_ == "CCONJ"
            ):  
                src = SectionResourcesConj(token_between, self._sections_and_resources)
                self._sections_and_resources = [src]
        else:
            # not supported more than 2
            # TODO ?
            return

    def getSectionResourceStr(self):
        """return _sections_and_resources in string sperated by ',' """
        s = ""
        for sr in self._sections_and_resources:
            s = s + ", " + sr.getSectionResourceStr()
        return s[2:]

    def getSectionStr(self):
        """return sections of _sections_and_resources in string seperated by ',' """
        s = ""
        for sr in self._sections_and_resources:
            s = s + ", " + sr.getSectionTextStr()
        return s[2:]

    def getResourceStr(self):
        """return resources of _sections_and_resources in string sperated by ',' """
        s = ""
        for sr in self._sections_and_resources:
            s += ", " + sr.getResourceTextStr()
        return s[2:]

    def info(self):
        """for information. return text representation for the identified elements """
        return [sr.info() for sr in self._sections_and_resources]

    def mergeSpanFromKeywordAndTermDefinition(self, k, t):
        """combine two dictionay of the same key together.

        Args:
            k (dict): key = string("SECTION" or "RESOURCE"), value = spans 
            t (dict): key = string("SECTION" or "RESOURCE") , value = spans

        Returns:
            list of SectionResource: combine Section and Resource if they are related to one SectionResource.  
        """
        sections = mergeList(k["SECTION"], t["SECTION"])
        resources = mergeList(k["RESOURCE"], t["RESOURCE"])
        resources = removeOverWrappingFromResouces( resources, sections, self._doc )  
        return self.connectSectionAndResource(sections, resources)

    def isPrecedeWith(self, span):
        """check if span is precede with self._validPrecede.

        Args:
            span (Scacy's span): span to be checked

        Returns:
            Boolean : return True if the span is precede with one of self._validPrecede, otherwise return False.
        """
        if self._doc[span.start - 1].lemma_ in self._validPrecede:
            return True
        else:
            return False

    def connectSectionAndResource(self, sections, resources):
        """ group together Section and Resource objects into SectionResource objects.
            If no Resource is related to a Section, then SectionResource is created with the Section with Resource = None in the SectionResource.
            If no Section is related to a Resource, then SectionResource is created with the Resource with Section = None in the SectionResource.
        Args:
            sections (list of Sections): sections to be checked
            resources (list of Resources): resources to be checked

        Returns:
            list of SectionResource: combined Section and Resource objects
        """
        srs = [] #list of SectionResource identified and to be returned
        s_used = [] #keep track of whether the token is already identified or not as Section
        r_used = [] #keep track of whether the toke is already identified or not as Resource

        #looping thorugh sections
        for s in sections:
            # finding a partern, "Section of Resource"
            if len(self._doc) > s["span"].end and self._doc[s["span"].end].text == "of":
                for r in resources:
                    if (not (r in r_used)) and (
                        isSectionOfResourcePattern(self._doc, r["span"], s["span"])
                    ):  # this resource is "section of resource"
                        s["confidence"].append(Confidence.Pattern_of)
                        r["confidence"].append(Confidence.Pattern_of)
                        #if section is precede with "this", add the confidence
                        if self.isPrecedeWith(s["span"]):
                            s["confidence"].append(Confidence.DET_This)
                        #if resource is precede with "this", add the confidence    
                        if self.isPrecedeWith(r["span"]):
                            r["confidence"].append(Confidence.DET_This)
                        #create SectionResource object
                        srs.append(
                            SectionResource(
                                Section(
                                    s["span"], s["confidence"], isSectionFit(s["span"])
                                ),
                                Resource(
                                    r["span"], r["confidence"], isResourceFit(r["span"])
                                ),
                            )
                        )
                        s_used.append(s)
                        r_used.append(r)
                        continue
            else:
                
                for r in resources:
                    if not (r in r_used):
                        # finding a pattern, "Resource Section"
                        if r["span"].end == s["span"].start:  
                            #resource is immidiately followed by section, then assign the confidence
                            s["confidence"].append(Confidence.Pattern_resource_section)
                            r["confidence"].append(Confidence.Pattern_resource_section)
                            #if section is precede with "this", add the confidence 
                            if self.isPrecedeWith(s["span"]):
                                s["confidence"].append(Confidence.DET_This)
                            #if resource is precede with "this", add the confidence 
                            if self.isPrecedeWith(r["span"]):
                                r["confidence"].append(Confidence.DET_This)
                            #create SectionResource object    
                            srs.append(
                                SectionResource(
                                    Section(
                                        s["span"],
                                        s["confidence"],
                                        isSectionFit(s["span"]),
                                    ),
                                    Resource(
                                        r["span"],
                                        r["confidence"],
                                        isResourceFit(r["span"]),
                                    ),
                                )
                            )
                            s_used.append(s)
                            r_used.append(r)
                            continue
                        #finding a pattern "Resource, Section"
                        #resource is followed ",", then section, then assign the confidence
                        elif (
                            len(self._doc) > r["span"].end + 1
                            and self._doc[r["span"].end].text == ","
                            and s["span"].start == r["span"].end + 1
                        ): 
                            s["confidence"].append(Confidence.Pattern_resource_section)
                            r["confidence"].append(Confidence.Pattern_resource_section)
                            #if section is precede with "this", add the confidence 
                            if self.isPrecedeWith(s["span"]):
                                s["confidence"].append(Confidence.DET_This)
                            #if resource is precede with "this", add the confidence     
                            if self.isPrecedeWith(r["span"]):
                                r["confidence"].append(Confidence.DET_This)
                            #create SectionResource object    
                            srs.append(
                                SectionResource(
                                    Section(
                                        s["span"],
                                        s["confidence"],
                                        isSectionFit(s["span"]),
                                    ),
                                    Resource(
                                        r["span"],
                                        r["confidence"],
                                        isResourceFit(r["span"]),
                                    ),
                                )
                            )
                            s_used.append(s)
                            r_used.append(r)
                            continue
        s_not_used = [s for s in sections if not (s in s_used)]
        for s in s_not_used:
            #if section is precede with "this", add the confidence 
            if self.isPrecedeWith(s["span"]):
                s["confidence"].append(Confidence.DET_This)
            #create SectionResource with None Resource
            srs.append(
                SectionResource(
                    Section(s["span"], s["confidence"], isSectionFit(s["span"])), None
                )
            )

        r_not_used = [r for r in resources if not (r in r_used)]
        for r in r_not_used:
            #if resource is precede with "this", add the confidence 
            if self.isPrecedeWith(r["span"]):
                r["confidence"].append(Confidence.DET_This)
            #create SectionResource with None Section    
            srs.append(
                SectionResource(
                    None,
                    Resource(r["span"], r["confidence"], isResourceFit(r["span"])),
                )
            )
            r_used.append(r)

        return srs


def mergeList(s_kw, s_tm):
    """merging list of spans in s_kw and s_tm together if both contains the same span or a patrial match in lemma text.

    Args:
        s_kw (list of spans): spans found by matching term definition
        s_tm (list of spans): spans found with Patterns "Start With"

    Returns:
        list of Span: Merged list
    """
    merged = []
    for sk in s_kw:
        if sk in s_tm:
            merged.append(
                {"span": sk, "confidence": [Confidence.Term, Confidence.StartsWith]}
            )
        elif spanLemmaInReturnSpans(sk, s_tm) == False:
            merged.append({"span": sk, "confidence": [Confidence.StartsWith]})
    for st in s_tm:
        if not (st in s_kw) and (
            spanLemmaInReturnSpans(st, s_kw) == False
        ):  # kw Table ASCS-2949, tm = ASCS-2949 then tm is not included
            merged.append({"span": st, "confidence": [Confidence.Term]})

    return merged


def spanLemmaInReturnSpans(span, lstSpans):
    """Check if span's lemma is in list of lstSpans.
       For example span text is "AS3059" and lstSpan = ["SAE AS3059], then return True
    Args:
        span (spacy's Span): span to be checked
        lstSpans (list of Spans): list of spans

    Returns:
        boolean: _description_
    """
    for aspan in lstSpans:
        if (
            span.lemma_ in aspan.lemma_
            and span.start >= aspan.start
            and span.end <= aspan.end
        ):
            return True
    return False


def isSectionFit(section):
    """
        Check if Section is Fit or not
        unfit if in Term Definition as unfit
        unfit is its lemma text or lower text in in Pattern Defintion's keyword
        For example, if Section "this section" and "section" is in Pattern Defintition, it return True
        because "this section" != "section"
    Args:
        section (Section): section object

    Returns:
        Boolean: True if fit otherwise return False
    """
    if (
        section.text in SectionResourceParser.s_unfits
        or section.lemma_ in SectionResourceParser.s_startwith
        or section.text.lower() in SectionResourceParser.s_startwith
    ):
        return False
    else:
        return True


def isResourceFit(resource):
    """
        Check if Resource is Fit or not
        unfit if in Term Definition as unfit
        unfit is its lemma text or lower text in in Pattern Defintion's keyword
        For example, if Section "this resource" and "resource" is in Pattern Defintition, it return True
        because "this resource" != "resource"
    Args:
        section (Resource): resource object

    Returns:
        Boolean: True if fit otherwise return False
    """
    if (
        resource.text in SectionResourceParser.r_unfits
        or resource.lemma_ in SectionResourceParser.r_startwith
        or resource.text.lower() in SectionResourceParser.r_startwith
    ):
        return False
    else:
        return True


def isSectionOfResourcePattern(doc, rspan, sspan):
    """DET(this, the etc..) is removed from Resource.
       To boundle like "section ABC of this EFG" where Section = "Section ABC" and Recource = "EFG",
       check if Resource prior token is DET.

    Args:
        doc (_type_): _description_
        rspan (_type_): _description_
        sspan (_type_): _description_
    Returns:
        Boolean: True if Section and Resource should be bundled, otherwise False
    """

    if doc[rspan.start - 1].pos_ == "DET":
        if rspan.start - 1 == sspan.end + 1:
            return True
    elif rspan.start == sspan.end + 1:
        return True
    return False


def removeOverWrappingFromResouces(resources, sections, doc):
    """Creating updated list for Resources

    Args:
        resources (list of Resource): list of Resources to be checked.
        sections (list of Sections): list of Sections to be compared with
        doc (spacy's Doc): Spacy's original Doc object necessary for comparing.

    Returns:
        updated_resource(list of Resource): updated list for Resources
    """
    updated_resources = []
    for r in resources:
        updated_resources.append(removeOverWrappingFromResource(r, sections, doc))
    return updated_resources


def removeOverWrappingFromResource(r, ls, doc):
    """ If Resource noun-chunk contains Section, remove the Section portion from Resource.
        For example, Resource = "DR&O Section, Section = "Section ..." will be modified to Resource="DR&O" and Section="Section..."
        If not, just return original Resource.
        Returns:
            r(Resource): modified Resource or the original Resource.
    """
    
    for s in ls:
        if (
            s["span"].start == r["span"].start
        ):  # when Resource and Section are starts with same text - happens with "FAR" was in Pattern/Section by mistake, but "FAR" is removed from pattern
            return r
        elif s["span"].start > r["span"].start and s["span"].end <= r["span"].end:
            return {
                "span": doc[r["span"].start : s["span"].start],
                "confidence": r["confidence"],
            }
    return r

def findByTermDefinition(doc, matcher, invalids):
    """Find spans based on Term definition.

    Returns:
        list of Spans: spans find with Term Definition phrase matcher
    """
    returnSpans = set()
    matches = matcher(doc)
    for (
        match_id,
        start,
        end,
    ) in matches:  # match_id_string = nlp.vocab.strings[match_id] = OBJECT
        span = doc[start:end]
        if span.lemma_ in invalids:
            continue
        else:
            """
            With "...under SAE AS4059... , and Term Def with "AS3059", the matcher pick up both "SAE AS4059" and "AS3059".
            It seems like first pick up "SAE AS4059" and then "AS4059" so here NOT to include "AS4059" if "SAE AS4059" is already in
            returnSpans.
            span= AS4059,
            spans={SAE AS4059}
            """
            if spanLemmaInReturnSpans(span, returnSpans) == False:
                returnSpans.add(span)
    return list(returnSpans)


def isTokenInNounChunksAndNsubj(token, nounchunks):
    """Check if a nounchunk containing the token is connected from Dep:Root by nsubj or nsubjpass.
    Args:
        token (Spacy's token): token to be checked
        nounchunks (Spacy's span): nounchunks checking if token is in. 

    Returns:
        boolean: return True, if a nounchunk containing the token is connected from Dep:Root by nsubm or nsubjpass. Otherwise return False.
    """
    nc = isTokenInNounChunks(token, nounchunks)
    if (
        nc != None
        and nc.root.head.dep_ == "ROOT"
        and (nc.root.dep_ == "nsubj" or nc.root.dep_ == "nsubjpass")
    ):
        return True
    else:
        return False


def isTokenInNounChunks(token, nounchunks):
    """If token in one of the nounchunks, then return the nounchunk.

    Args:
        token (Spacy's token): token to be checked
        nounchunks (list of nounchunks): nounchunks checking if token is in.

    Returns:
        nounchunk(Spacy's span) or None: nouchunk if the token is in the nounchunk, otherwise return None.
    """
    for nc in nounchunks:
        if token in nc:
            return nc
    return None


# return None is 2nd+ token pos != "NUM"
def findSpan(token, kws, doc, invalids):
    """ find span from token based on endIndex return from isNextNumDashOrUnderScoreOrDot method.
        For example, if the text is "D200W020-01" and the token is "D200W020"(PRON).  The token is follwed by "-"(SYM) and then "01"(NUM).
        This method create a span "D200W020-01" from "D200W020".
        For example, the original requirement is "The REU(s) surface temperature shall be limited to the levels referred to in D6-44588 paragraph 4.7." 
        and token is "D6", and following each tokens "-", "44588", "paragraph", and "4.7" are checked, and span "D6-44588 paragraph 4.7" is returned.
        However, "ASCS Equipment operation" with "ASCS" token will only return "ASCS" span.
    Args:
        token (spacy's token): token that returning span starts with
        kws (list of strings): "start with" column words in Patterns.xlsx 
        doc (spacy'd doc): spacy's doc - requires to create span
        invalids (list of strings): invalid list for element

    Returns:
        span: span starts with token or None if the span is invalid
    """
    # if token is followed by another token
    if len(doc) > token.i + 1:
        endIndex = isNextNumDashOrUnderScoreOrDot(doc, token, kws)
        span = doc[token.i : endIndex]
    # the token is not followed by another token, then create a span with just the token.
    else:
        span = doc[token.i : token.i + 1]

    #if the span is invalid, return None.
    if span.lemma_ in invalids:
        return None
    else:
        return span


def isNextNumDashOrUnderScoreOrDot(doc, token, kws):
    """ return the endIndex to create span in the calling method if the token is followed by what is looking for.
        1. next token is based on POS
            For example, if the text is "Table 3.2.11.4" and the token (for section) is "Table" and it is follwed by PROPN("3.2.11.4") then return endIndex of "4".
            In this case, endIndex returned is used to create "Table 3.2.11.4" from the token "Table".
        2. next token is starts with in Pattern's "Start With" column words
            For example, if the text is "Table ASCS-5080" and the token (for section) is "Table" followed by token(ASCS-5080) where "ascs" is in Pattern's startswith.
            In this case, endIndex returned is used to create "Table ASCS-5080" from the token "Table". 
   
    Args:
        doc (spacy's Doc): spacy's Doc for this requirement.
        token (spacy's Token): token to be checked
        kws (list of strings): list of strings from Patterns.xlsx's "Start With" column.

    Returns:
        int: index of token in spacy's Doc
    """
    if len(doc) > token.i + 1:
        #if the token is followed by one of below
        if (
            doc[token.i + 1].pos_ == "NUM"
            or doc[token.i + 1].dep_ == "nummod"
            or doc[token.i + 1].pos_ == "NOUN"
            or doc[token.i + 1].pos_ == "PROPN"
        ):
            # if there is more token, check if that to be included
            if len(doc) > token.i + 2:
                return isNextNumDashOrUnderScoreOrDot(doc, doc[token.i + 1], kws)
            else: #if no more token to check
                return token.i + 2
        elif doc[token.i + 1].text == "-": #if token is followed by "-", then check more.
            return isNextNumDashOrUnderScoreOrDot(doc, doc[token.i + 1], kws)
        elif is_startswith_in_keywords(
            doc[token.i + 1], kws
        ):  # Table ASCS-5080, section_keyword (Table) followed by token(ASCS-5080) with a keyword "ascs"
            return isNextNumDashOrUnderScoreOrDot(doc, doc[token.i + 1], kws)
        else:
            return token.i + 1
    else: #no more token to check, then return token's index
        return token.i


def is_startswith_in_keywords(token, keywords):
    """Check if token.text.lower() starts with one of keywords
       and not pos is "PROPN" and token.text.lower() is not token.lemma_
       For exampke, token.text = Parts, seconds, REUs returns False
       because SECTION will likely to starts with "Part" (ie., Part 123) not with "Parts"
    Args:
        token (spacky's token): token to be compared
        keywords (list of strings): list of keywords(string)

    Returns:
        Boolean: True if the token starts with one of keywords
    """
    for keyword in keywords:
        if token.text.lower().startswith(keyword) == True:
            if token.pos_ != "PROPN" and token.text.lower() != str(token.lemma_):
                return False  # ie., reus vs. reu, seconds vs. second, parts vs. part
            return True
    return False

    # lines = []# read_excel2(requirement_file["tab"], [requirement_file["column"]], requirement_file["name"])[requirement_file["column"]]
    # lines.append('The equipment shall withstand the ultimate abuse loads defined in the Table ASCS-2949 per the equipment applicability defined in Table ASCS-5080.')
    # lines.append("The main landing gear shall operate within the environments specified in this section.")
    # lines.append("The IFCE equipment shall operate within the environments specified in this section.")
    # lines.append("All sensors shall meet the environmental requirements detailed in Section 3.1 of this SCD.")
    # lines.append("The Secondary Lock Actuator shall operate within the environments specified in this section.")
    # lines.append("The HCM shall be designed to operate in the airplane environment described in DR&O Section 2.12.")
    # lines.append("The SLG shall meet the environment requirements specified in D200W020-01.")
    # lines.append("The WAP shall not suffer damage when exposed to an overpressure altitude per Section 4.6.3 of SRO.")
    # lines.append("The WAP shall operate correctly in the environment specified by section 4.6.3 of this SCD and DRO section 2.12")
    # lines.append("The HSTA shall show no susceptibility when exposed to Category R (3.1 meters) DAL B HIRF levels per ASCS-11019.")
    # lines.append("The PCU internal leakage shall not be less than 3.1 meters when exposed to fluid temperature defined in Section 3.2.6.1.")
    # lines.append("WAP equipment furnished under the requirements of this SCD shall operate within the environments specified in section 2.12.")
    # lines.append("The HSTA shall meet the maximum temperature and internal pressure environment provided in Table 3.2.11.4-1.")
    # lines.append("The LE REU shall meet all performance requirements during and after exposure to temperature in accordance with D048W400-01.")
    # lines.append("The BEPS shall show no failure, malfunction, or out-of-tolerance performance when exposed to the test conditions of REU196.")
    # lines.append("The HCM shall not be damaged in the event the operating environment exceeds the thermal environments defined in this SCD.")
    # lines.append("The new airplane shall meet all performance requirements during and after exposure to Temperature in accordance with D048W400-01.")
    # lines.append("IFCE Equipment shall meet the all requirements of this SCD during and after exposure to 3.1 meters fluid temperatures up to 3.1 meters.")
    # lines.append("On the new airplane, the WAP shall meet all performance requirements during and after experiencing Temperature in accordance with D048W400-01.")
    # lines.append("The unit shall meet all performance requirements after exposure to Sand and Dust in accordance with Section 12 of D048W400-01, Category S.")
    # lines.append("The Secondary Lock Actuator shall be designed to operate with limited exposure to the fluid contamination levels described under SAE AS4059, Class 12.")
    # lines.append("To ensure a sanitized surface, the HSTA shall meet all requirements of this SCD after exposure to Fungus Resistance in accordance with Section 2.12 of DR&O.")
    # lines.append("The main landing gear shall meet the performance requirements when exposed to the conditions described in the altitude and decompression test of D200Z001.")
    # lines.append("The SLG shall meet all performance requirements after exposure to Fungus Resistance in accordance with Section 12 S of D048W400-01.")
    # lines.append("BEPS shall meet all performance requirements during and after exposure to Waterproofness in accordance with Section 12 of D048W400-01, Category S.")
    # lines.append("The HSTA shall be designed to meet functional and durability requirements after exposure to the fungi environment of Section 12 Category S of D048W400-01.")
    # lines.append("The main landing gear exposed to direct lightning attachment shall continue to perform its intended function after exposure to threat levels defined in ARP5412B.")
    # lines.append("The Wireless Access Point shall remain structurally intact after exposure to the Ultimate acceleration loads defined in D6-81926, Table 5-1.")
    # lines.append("The BEPS shall operate within performance specification during and after exposure to HIRF environment I and II as defined in 14 CFR 25.1317.")
    # lines.append("The new airplane shall be designed to meet the performance requirements when subjected to any of the following environmental conditions as specified in D200Z001.")
    # lines.append("Physical separation shall be maintained during and after exposure to environmental conditions, as defined by document D200W020-01: 777X General Technical Requirements.")
    # lines.append("The main landing gear shall adhere to the environmental requirements specified in the General Technical Requirements document section 3.1.3, \"Environmental Requirements\".")
    # lines.append("It shall be verified by test that the ELMS will not induce loss of the BEPS under EMI/Lightning environment conditions per Section 12 of D048W400-01, Category S.")
    # lines.append("When batteries are used on the equipment, they shall comply with Section 3.1 of D6-81926 when exposed to a humid environment as described in Environment Guide.")
    # lines.append("The units shall operate at the nominal speeds in Table 3.2.2.1 without performance degradation.")
    # lines.append("The units shall operate at the survival speeds in Table 3.2.2.2 without permanent damage.")
    # lines.append("The system shall withstand the overpressure conditions as defined in D200Z001.")
    # lines.append("The IFCE shall withstand the ultimate abuse loads defined in the table 3.1.7.19-1.")
    # lines.append("The BEPS equipment shall withstand the ultimate abuse loads defined in the Table BEPS12444.")
    # lines.append("The WAP shall withstand the ultimate abuse loads defined in Table 3-2.")
    # lines.append("The IFCE shall be capable of withstanding an ultimate load equal to 1.5 times the limit load value in FSS 1005.")
    # lines.append("The equipment shall be designed to support limit loads as defined in Table ELMS-106845, without any detrimental permanent deformation.")
    # lines.append("The HSTA shall be designed to withstand the Acceleration Ultimate Load Factors per D6-81926 Table 4-1 Zone 2 without structural failure.")
    # lines.append("The equipment shall withstand the ultimate abuse loads defined in the Table ASCS-2949 per the equipment applicability defined in Table ASCS-5080.")
    # lines.append("The System shall withstand a 1,300 volt peak lightning pulse induced on the generator feeders as shown in DO-160G Figure 22-2 (Voltage Waveform 2).")
    # lines.append("The BEPS shall perform undervoltage protections per Figure BEPS10634.")
    # lines.append("The HSTA shall provide protection to ensure output frequency does not exceed the abnormal frequency limits of BEPS10736.")
    # lines.append("All forged parts shall comply with the requirements of D6-53172.")
    # lines.append("The aircraft structure shall comply with the requirements of CFR 25.621 and D6-53172 after a tail strike.")
    # lines.append("The electrical wiring shall comply with FAR 25.1713 (c) (Fire protection: EWIS) after a lightning strike.")
    # lines.append("When batteries are used on the equipment, they shall comply with Section 3.3.5 of D6-36462 when exposed to a humid environment as described in Environment Guide.")
    # lines.append("The mounted components (i.e., valves and sensors) shall comply with D6-81926 in order to reduce component damage.")
    # lines.append("To ensure a sanitized surface, the HSTA shall meet all requirements of this SCD after exposure to Fungus Resistance in accordance with Section 2.12-3 of DR&O")
