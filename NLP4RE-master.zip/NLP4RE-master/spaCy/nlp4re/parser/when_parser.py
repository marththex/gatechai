from nlp4re.utils.matcher_terms import create_phrase_matcher
from nlp4re.elements.when import When
from nlp4re.parser.element_parser import ElementParser
from dataclasses import dataclass, field


@dataclass
class WhenParser(ElementParser):
    """ Parser to identify "during and after", "during", "after".
        Subclass for ElementParser

        Args:
        _when (list of When): identified When elements.
    """
    
    _when: list[When] = field(default_factory=list)

    # creating spacy's Phrase Matcher for 3 phrases.
    when_matcher = create_phrase_matcher( "when", ["during and after", "during", "after"]    )

    def process(self):
        """  
        required method which process a line of text, create When objects, assigned to self._when, and return them.
        
        Returns:
            List[ArticleAgent]: identified elements
        """
        matches = WhenParser.when_matcher(self._doc)
        if len(matches) == 1:
            for match_id, start, end in matches:
                self._when.append(When(self._doc[start:end]))
        elif len(matches) == 3:  # len(matches) == 3: #during and after
            for match_id, start, end in matches:
                if end != start + 1:
                    self._when.append(When(self._doc[start:end]))
                    break
        return self._when

    def info(self):
        """return text representation for the identified elements """
        return [c.info() for c in self._when]
