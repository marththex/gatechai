import spacy

#out spacy configulation file what pipeline we are using 
#change to med maybe sufficient 
#pipeline = "en_core_web_lg"
pipeline = "en_core_web_trf"
nlp = spacy.load(pipeline)
