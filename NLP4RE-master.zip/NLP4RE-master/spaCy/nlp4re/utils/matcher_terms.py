import pandas as pd
from spacy.matcher import PhraseMatcher
from nlp4re.spacy_config import nlp
from nlp4re.utils.util import *

term_filename:str = "nlp4re/Term Definitions.xlsx"
"""Path to Term Definition excel file."""
term_def_tabs = { # element name, excel tab name
    "OBJECT": "OBJECT",
    "CONDITION": "CONDITION",
    "EVENT": "EVENT",
    "STATE": "STATE",
    "SECTION": "SECTION",
    "RESOURCE": "RESOURCE",
    "CHARACTERISTIC": "CHARACTERISTIC",
    "BOUNDARY": "BOUNDARY",
    "VALUE": "VALUE",
}
"""Map of element name to corresponding tab names in the TermDef spreadsheet"""
term_def_column_names: list[str] = ["Name", "Acronym", "Aliases", "Units"]
"""Names of the columns to read from each TermDef spreadsheet tab."""
# Units are included in entries in the VALUE tab but may not necessary

pattern_filename = "nlp4re/Patterns.xlsx"
"""Full path to the Excel file containing the patterns."""
pattern_tabs = {
    "CONDITION": "CONDITION",
    "EVENT": "EVENT",
    "SECTION": "SECTION",
    "RESOURCE": "RESOURCE",
    "CHARACTERISTIC": "CHARACTERISTIC",
}
"""Map of element name to corresponding tab names in the Patterns spreadsheet"""
pattern_column_names = ["After",  "Keyword", "Start with"]
"""Names of the columns to read from each Patterns spreadsheet tab."""

# patterns are converted to lower case
def get_pattern_dict():
    cell_values = {}
    for tab in pattern_tabs.keys():
        cell_values[tab] = read_excel(
            tab, pattern_column_names, pattern_filename, as_lower=True
        )  ##{"Before":['A', "b", "C"], "After":["C", "D", "E"], "Middle": ["F, G"] }
    return cell_values  # {"CONDITION": {"Before":['A', "b", "C"], "After":["C", "D", "E"], "Middle": ["F, G"] }}

def create_phrase_matcher(pattern_name, words):
    """create spacy's PhraseMatcher for words in lowercase.

    Args:
        pattern_name (string): name for the pharse matcher to be created.
        words (list(string)): words to be included in the phrase matcher

    Returns:
        PhraseMatcher: the phrasematcher for this words
    """
    matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
    # nlp (spacy.lang.en.English): spacy's nlp object
    patterns = [nlp.make_doc(text) for text in words]
    matcher.add(pattern_name, patterns)
    return matcher

def create_phrase_matcher_dict(
    term_tab, terms_dict
):  # {'object':{'Name1':['b', 'c'], 'Name2:['d']}
    """_summary_

    Args:
        term_tab (string): name for the pharse matcher
        terms_dict (dict):
            key(string) = <tabname>-index (i.e. 'OBJECT-0')
            value(dict) :
                key(string): column name (i.e. 'Name')
                value(list(string)): cell values (i.e. ['Creaw Oxygen Hose'])
            i.e.
            'OBJECT-0' : {'Name': ['Crew Oxygen Hose'], 'Acronym': [], 'Aliases': []}
            'OBJCET-1' : {'Name': ['Emergency Slide and Raft'], 'Acronym': [], 'Aliases': ['slide/raft']}

    Returns:
        PhraseMatcher: the phrasematcher for this words in the term_dict.value
    """
    matcher = PhraseMatcher(nlp.vocab, attr="LOWER")
    terms = []
    for i, v in terms_dict.items():
        for w in v.values():
            for text in w:
                terms.append(str(text))
    # nlp (spacy.lang.en.English): spacy's nlp object
    patterns = [nlp.make_doc(text) for text in terms]
    matcher.add(term_tab, patterns)
    return matcher

# [{"AGENT": "OBJECT", "CONDITION": "CONDITION", "EVENT": "EVENT", "SECTION": "SECTION", "RESOURCE": "RESOURCE" }]
def get_term_def_info():  # [{Element, Tab}, ......]
    """Read the Term Definition excel file for all tabs and all cells and create
    Returns:
        term_def_info (dict):
            key (string) : a key of term_def_tabs defined above (ie.,  "AGENT", "CONDITION", ...)
            value (dict):
            {
                matcher(spacy.matcher.phrasematcher.PhraseMatcher): for the element,
                dict_terms(dict) :
                    key (string) : <tab_name>-index
                    value(dict): {column name: [list of columns values]}
                    i.e., )
                        for tab_name is "OBJECT",
                        'OBJECT-0' : {'Name': ['Crew Oxygen Hose'], 'Acronym': [], 'Aliases': []}
                        'OBJCET-1' : {'Name': ['Emergency Slide and Raft'], 'Acronym': [], 'Aliases': ['slide/raft']}
                        for tab_name is "CONDITION",
                        'CONDITION-1: {'Name': ['Category R Design Assurance Level A High Intensity Radiated Field Levels'], 'Acronym': ['Category R DAL A HIRF Levels'], 'Aliases': ['hirf environment i']}
                invalids(list(string)): for invalid for this key.  In Term Definition, the word is prefix with "-". i.e.,) -probability
                unfits(list(string)): for unfit words for this key.  In Term Definition, this word is prefix with "*" i.e.,) *sensor
            }
    """
    term_def_info:dict = {}
    for k in term_def_tabs.keys():
        # read term definition excel file for term_def_column_names column for tab
        [dict_terms, invalids, unfits] = read_excel_dict(
            term_def_tabs[k], term_def_column_names, term_filename
        )
        matcher = create_phrase_matcher_dict(term_def_tabs[k], dict_terms)
        term_def_info[k] = [matcher, dict_terms, invalids, unfits]
    return term_def_info
