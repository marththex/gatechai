from typing import Iterable
import pandas as pd
from nlp4re.spacy_config import nlp
from spacy.tokens import Token



def convert_to_capitalize_singular_noun(
    token, token_lemma, token_lower_lemma, convert_to_singular=True
):
    """ converting to singular and capitalize and return if convert_to_singular is True.
        If convert_to_singular is False, then return just the token in text, but after capitalzed.
        This is similar to convert_to_singular_noun, maybe able to merge later.
    Args:
        token (spacy's token): token to be evaluated
        token_lemma (string): lemma version of token text
        token_lower_lemma (string): lowercase of the lemma text
        convert_to_singular (bool, optional): If True, it convert token to lemma and capitalze and return. Defaults to True.

    Returns:
        string: return string
    """
    if convert_to_singular:
        # l = token.lemma_ #REUs -> reu /HHHS -> HHHS/ Transducers -> transducers(not removing s)
        if token.text.startswith(
            token_lemma.upper()
        ):  # REUs startsWith( reu.upper()), then return REU (token.lemma_.upper()), HHHS -> return HHHS.upper(),
            return token_lemma.upper()
        elif token.text[0].isupper():
            if (
                token.text[0 : len(token.text) - 1].upper() + "s"
            ) == token.text:  # HSTAs lemma is HSTAs - to handle the case
                return token.text[0 : len(token.text) - 1]  # HSTA
            else:  # for "transducers"
                return token_lower_lemma.capitalize()
                # Transducers - >Transducers(lemma) -> nlp(transducers) = transducer
                # Transducer
        return token_lemma.capitalize()  # hoses -> hose -> return Hose
    else:
        return token.text


def convert_to_singular_noun(token, convert_to_singular=True):
    """If convert_to_singular is True, 
        If convert_to_singular is False, just retrun token in text lemma format.
        This is similar to convert_to_capitalize_singular_noun, maybe able to merge later.

    Args:
        token (Spacy's token): a token to be evaluated
        convert_to_singular (bool, optional): If True, convert.  If False, no conversiton. Defaults to True.

    Returns:
        string : text representation of the token
    """
    if convert_to_singular:
        l = (token.lemma_)  # REUs -> reu /HHHS -> HHHS/ Transducers -> transducers(not removing s)
        if token.text.startswith(
            l.upper()
        ):  # REUs startsWith( reu.upper()), then return REU, HHHS -> return HHHS.upper(),
            return l.upper()
        elif token.text[0].isupper():
            if (
                token.text[0 : len(token.text) - 1].upper() + "s"
            ) == token.text:  # HSTAs lemma is HSTAs - to handle the case
                return token.text[0 : len(token.text) - 1]  # Transducer
            else:
                l = next(
                    token.lemma_ for token in nlp(token.text.lower())
                )  # Transducers - >Transducers(lemma) -> nlp(transducers) = trasducer
                return token.text[0].upper() + l[1 : len(l)]  # Transducer
        return l  # hoses -> hose -> return hose
    else:
        return token.text

# def get_singular_noun_root_line(nlp, line, doc): 
#     """De-pluralize the agent, in-place (i.e. all new airplanes are black. -> All new airplane are black.)--  to use for phrasematching
#     Args:
#         nlp ([type]): entire document NLP model
#         line ([type]): sentence being processed
#         doc ([type]): entire spaCy document object
#     Returns:
#         [str]: 
#     """
#     line2 = ""
#     for token in doc:
#         #matching = [s for s in noun_chunks_root_text if token.text in s]
#         #if len(matching) > 0 : #if token is chunk.root convert
#         if token.tag_ in ["NNS", "NNPS"]:
#             token2_text = convert_to_singular_noun(token, True)
#             line2 += token2_text + token.whitespace_
#         else:
#             line2 += ''.join(token.text + token.whitespace_)
#     return line2.strip()


def to_lemma_text_set(tokens:Iterable[Token]):
    """Modify tokens into lemma format

    Args:
        tokens (list): tokens to be evaluated

    Returns:
        set : tokens in lemma format
    """
    r = set()
    for token in tokens:
        r.add(token.lemma_)
    return r


def find_nounchunks_for_matcher(doc, matcher, line, noun_chunks, use_lemma=True):
    """
    Find matched word in the line.

    Args:
        doc (spacy.doc): spacy's parsed doc
        matcher (spacy's matcher): spacy's matcher used to find matched words from line
        line (str): string finding matched line
        noun_chunks (spacy's noun chunks): spacy's noun_chunks included in in return dict.value
        use_lemma (bool, optional): wheather to use lemma version of line to be used to find matched words. Defaults to True.

    Returns:
        dict (key = the mateched span, value = nounchunk contain the matched span):
        For example, key = "ACES", value = "ACES Equipment"
    """
    # replace original (non-lemmatized) noun chunks
    ncs_term = {}  # value = nounchunk contains term
    # key = terms noun_chunks found with term definition matcher by parsing lemmetized requirement text.
    # ELMS lemma = elm for en_core_web_trf NOUN --------------- use_lemma need to be False to get mathing
    # ELMS lemma = ELMS for en_core_web_lg PROPN
    if use_lemma == False:
        doc2 = nlp(line)  
    else:
        line2 = get_singular_noun_root_line(doc)  # line2 is lemma version of line
        doc2 = nlp(line2)
        if len(doc) != len(doc2):
            # when len tokens are difference with original vs. lemma version, forcefully change to original version.  Because the below logic only works when they are the same
            # For example, "The vehicle shall weigh less than 300lbs" ("300lbs" is one token) has 7 tokens, 
            # but its lemma version "The vehicle shall weigh less than 300lb" has 8 tokens ("300lb" has 2 tokens:"300", "lb")
            doc2 = nlp(line)

    matches = matcher(doc2)
    for ( match_id, start, end ) in matches:  # match_id_string = nlp.vocab.strings[match_id] = OBJECT
        #finding span for the matched element
        term_span = doc[start:end]
        for chunk in noun_chunks:
            # print(f"chunk: {chunk.text}, {len(chunk)}")
            if chunk in ncs_term:
                continue
            if chunk[0].pos_ == "DET" and doc[chunk.start + 1 : chunk.end] == term_span:
                assert doc[chunk.start : chunk.end].text.startswith(chunk.text)
                ncs_term[term_span] = chunk
                break
            elif (
                term_span.text == chunk.text
                and term_span.start == chunk.start
                and term_span.end == chunk.end
            ):  # comparing lemma chunk with team (term_span text)
                # elif is_noun_chunk_the_same(term_span, chunk): #doc2[start:end] and doc[start:end] have the same text and index
                assert doc[chunk.start : chunk.end].text.startswith(chunk.text)
                # r.append(doc[chunk.start:chunk.end]) #put chunk(doc2/line) but based on doc/line
                ncs_term[term_span] = chunk
                break
            # term_span = "section 3.1.3" and chunk = "the General Technical Requirements document section"
            elif is_part_of_spanAText_in_spanBText(term_span, chunk):  # term_span = "DR&O" and chunk = "DR&O Section"
                ncs_term[term_span] = chunk
                break
            elif is_part_of_spanAText_in_spanBText(chunk, term_span):  # term_span = "Section 1.1.2" and chunk = "Section"
                ncs_term[term_span] = chunk
                break

        if term_span in ncs_term.keys() == False:  # not in noun_chunk but in term definition (ie., SECTION's "Table 5-1" is not noun-chunk => Table(Noun), 5-(NUM), 1(NUM))
            ncs_term[term_span] = None
    return ncs_term


def initialize_requirements_with_first_element(all, length, elements):
    for j in range((int)(length/len(elements))):
        for e in elements:
            all.append([e])
    return all

def to_text_set(tokens):
    """Collect token texts into a set."""
    r = set()
    for token in tokens:
        r.add(token.text)
    return r

def expand_requirements(all, length, elements):
    """_summary_

    _extended_summary_

    Args:
        all (_type_): _description_
        length (_type_): _description_
        elements (_type_): _description_

    Returns:
        _type_: _description_
    """
    i = 0
    for j in range((int)(length/len(elements))):
        for e in elements:
            all[i].append(e)
            i = i + 1
    return all  

def remove_DET_from_n_chunk(chunk):
    if chunk[0].pos_ == "DET":
        return chunk[1:]
    else:
        return chunk


def find_pattern_matching_chunk(noun_chunk_before_2gram_dep, dict_terms, patterns_dict,
        invalids, pattern_header = "After"):
    """Collect identified noun chunks that match patterns for this element type.
    Args:
        noun_chunk_before_2gram_dep ([type]): All/remaining unmatched noun chunks
        dict_terms ([type]): [description]
        patterns_dict ([type]): [description]
        invalids ([type]): [description]
        pattern_header (str, optional): [description]. Defaults to "After".
    Returns:
        [type]: [description]
    """
    element_noun_chunks = [] #ie., table 123
    used_noun_chunks = [] #this is different from element_noun_chunk if DET (ie., the) is in. ie., the table
    if (len(noun_chunk_before_2gram_dep) != 0 ):
        for after in patterns_dict[pattern_header]:
            if after in noun_chunk_before_2gram_dep:
                for v_possible_with_det in noun_chunk_before_2gram_dep[after]:
                    v = remove_DET_from_n_chunk(v_possible_with_det) #'The table' to 'table'
                    if len(to_text_set(v) & set(invalids)) == 0: #v is not in invalids
                        # if in term definition then replace confidenct from 0.9 to 1 and appending method with & After
                        if v in dict_terms.keys():
                            cv = dict_terms[v]
                            cv.confidence = 1
                            cv.method += " & " + pattern_header
                        else:
                            inTerm = False
                            for x in dict_terms.keys(): #x is in term definition
                                if v.start >= x.start and v.end <= x.end: #v = Setction x = Section 3.1 , v = table, x = table 123
                                    cv = dict_terms[x]
                                    cv.confidence = 1
                                    cv.method += " & " + pattern_header
                                    inTerm = True
                            if inTerm == False:
                                #assume no same condition is with more than one after keywords (ie., A is expose to B and exposure to C)  
                                element_noun_chunks.append(v)
                                used_noun_chunks.append(v_possible_with_det)
                    else:
                        print(f"{v} is in invalid:{invalids}")
    return element_noun_chunks, used_noun_chunks

if __name__ == '__main__':
    agents = ["AAA", "BBB"]
    when = ["during", "after", "during and after"]
    conditions = ["CONDITION1", "CONDITION2", "CONDITON3", "CONDITION4"]
    sections = ["SECTION"]
    resources = ["RESOURCE"]
    
    length = len(agents)* len(when) * len(sections)* len(resources)
    all =[] 
    initialize_requirements_with_first_element(all, length, agents)
    expand_requirements(all, length, when)
    expand_requirements(all, length, sections)
    expand_requirements(all, length, resources)
    print (all)        

def is_part_of_spanAText_in_spanBText(spanA, spanB):
    """Checking if spanB contains spanA

    Args:
        spanA (spacy's Span): span to be evaluated
        spanB (spacy's Span): span to be evaluated

    Returns:
        boolean: True if spanA is in spanB
    """
    if spanA.text in spanB.text:
        if spanA.start >= spanB.start and spanA.end <= spanB.end:
            return True
    return False

def is_noun_chunk_the_same(a, b):
    if a.text == b.text and a.start == b.start and a.end == b.end:
        return True
    else:
        return False            

# def convert_to_singular_noun(token, convert_to_singular = True):
#     if convert_to_singular:
#         l = token.lemma_ #REUs -> reu /HHHS -> HHHS/ Transducers -> transducers(not removing s)
#         if token.text.startswith(l.upper()): #REUs startsWith( reu.upper()), then return REU, HHHS -> return HHHS.upper(),
#             return l.upper()
#         elif token.text[0].isupper():
#             if ((token.text[0: len(token.text)-1].upper() + "s") == token.text) :#HSTAs lemma is HSTAs - to handle the case
#                 return token.text[0: len(token.text)-1] # Transducer
#             else:
#                 l = next(token.lemma_ for token in nlp(token.text.lower())) #Transducers - >Transducers(lemma) -> nlp(transducers) = trasducer
#                 return token.text[0].upper() + l[1: len(l)] # Transducer
#         return l #hoses -> hose -> return hose
#     else:
#         return token.text

# # pluralize the agent in-place (ie., All new airplanes are black. -> All new airplane are black.)--  to use for phrasematching
def get_singular_noun_root_line(doc):
    """convert line of text with singular if its token is NNS or NNPS and return 

    Args:
        doc (Spacy's doc): doc to be evaluated (line)

    Returns:
        string: string representation of line
    """

    line2 = ""
    for token in doc:
        if token.tag_ in ["NNS", "NNPS"]:
            token2_text = convert_to_singular_noun(token, True)
            line2 += token2_text + token.whitespace_
        else:
            line2 += "".join(token.text + token.whitespace_)
    return line2.strip()
 

# read excel file and return dict.  key = column_name
def read_excel(sheet_name, column_names, filename, includeEmpty=False, as_lower=False):
    """read excel file

    Args:
        sheet_name (string): sheet/tab name
        column_names (string): column names
        filename (string): file name
        includeEmpty (bool, optional): If True include empty cell, otherwise not include empty cell. Defaults to False.
        as_lower (bool, optional): If True lower the case to all cell values, otherwise not. Defaults to False.

    Returns:
        dict: key(string) = column name, value= cell values
    """
    data = pd.read_excel(f"{filename}", sheet_name=sheet_name)
    dict_terms = {}
    for column_name in column_names:
        terms = []
        object_names = pd.DataFrame(data, columns=[column_name])
        columns = list(object_names)

        for i in columns:
            for rowIndex in range(len(object_names[i])):
                cell_value = object_names[i][rowIndex]
                if pd.isna(cell_value):  # empty cell
                    if includeEmpty:
                        terms.append("")
                    else:
                        continue
                elif isinstance(cell_value, str):
                    if as_lower:
                        terms.append(cell_value.strip().lower())
                    else:
                        terms.append(cell_value.strip())
        dict_terms[column_name] = terms
    # example for dist_terms:
    # {'CONDITION': {'Before': ['specified in', 'describe in'], 'After': ['exposure to', 'exposed to', 'specified in', 'defined in', 'exposure in', 'withstand to', 'operate to', 'described in', 'meet to', 'operate in', 'meet'], 'Middle': ['after experiencing, in accordance with']}}
    return dict_terms


def read_excel_dict(sheet_name, column_names, filename):
    """_summary_

    Args:
        sheet_name (string): sheet/tab name
        column_names (string): column names
        filename (string): file name

    Returns:
        list: list[0] = dict of term definition (key(string)= sheetname+"-"+ line_number (ie., "OBJECT-0"), 
                                                value = dict(key=column name, value=cell cell value)) ,
              list[1] = list of invaluds words(string)
              list[1] = list of unfit words(string)
    """
    data = pd.read_excel(f"{filename}", sheet_name=sheet_name)
    term_values = {}
    invalids = []
    unfits = []
    di = pd.DataFrame(data).to_dict()

    for j in range(len(column_names)):
        if column_names[j] in di:
            for i, v in di[column_names[j]].items():
                if j == 0:
                    term_values[sheet_name + "-" + str(i)] = {}
                term_values[sheet_name + "-" + str(i)][column_names[j]] = []
                if pd.isna(v) == False:
                    if j == 0 and str(v).startswith("-"):
                        invalids.append(v[1 : len(v)])
                    elif j == 0 and str(v).startswith("*"):
                        unfits.append(v[1 : len(v)])
                    else:
                        for v in v.split(","):
                            term_values[sheet_name + "-" + str(i)][
                                column_names[j]
                            ].append(v.strip())
    return [term_values, invalids, unfits]


if __name__ == "__main__":
    """ Analyze a sample line """

    import spacy
    from spacy import displacy
    pipeline = "en_core_web_trf"
    nlp = spacy.load(pipeline)

    line = "The slide/raft shall be capable of withstanding exposure to salt spray."
    
    doc= nlp(line)
    print("noun_chunks===")
    for chunk in doc.noun_chunks:
        print(chunk.text, chunk.root.text, chunk.root.dep_, chunk.root.head.text)

    roots = [token for token in doc if token.head == token]
    print("root===")
    print(roots)
    print("lem====")
    for token in doc:
        print(token.text, token.lemma_, token.pos_, token.dep_)

    print("ner===")
    for ent in doc.ents:
        print(ent.text, ent.start_char, ent.end_char, ent.label_)

    print("")
    
    root = [token for token in doc if token.head == token][0] #only 1 ROOT
    print('root=',root)
    for e in root.lefts:
        print("TEXT	DEP	N_LEFTS	N_RIGHTS	ANCESTORS")
        print(e.text, e.pos_, e.dep_)    
        # e[0] = subject = list(root.lefts)[0]
       
        print(' '.join([str(token.text) for token in list(e.subtree)]))
        for descendant in e.subtree:
            print("subtree: " , descendant.text, descendant.dep_, descendant.n_lefts,
                    descendant.n_rights,
                    [ancestor.text for ancestor in descendant.ancestors])
            assert e is descendant or e.is_ancestor(descendant)
        print("")
    print("")        
    print("nounchunks===")        
    print([n.text for n in doc.noun_chunks])
    displacy.serve(doc, style="dep", options= {"fine_grain":True})  
    #displacy.render(doc, style="dep", jupyter=True, options={'distance':140}) 