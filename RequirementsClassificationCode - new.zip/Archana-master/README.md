# Archana
All files/scripts/code are listed below: 

1. V2_Multiclass_Requirement_classification.ipynb
    - Updated multiclass classification model
    - Uses random under sampling followed by stratified sampling 

2. requirements.csv  
    - this csv file contains all the requirements along with their labels 

3. multiclass 
    - this folder contains the saved weights for V2_Multiclass_Requirement_classification 
    - can be used to load the model directly and use `.predict` to predict the class that the requirement belongs to
