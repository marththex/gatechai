# Web-UI

## Requirements

### Python
The current code is tested and stable on Python v3.9.7.  The initial dependency list (provided manually, without versions), was:
```
flask
gunicorn
imbalanced-learn
keras
pandas
tensorflow
```
In the previous (Python 3.7.6) working environment, this expanded to
```
Flask==2.0.2
gunicorn==20.1.0
imbalanced-learn==0.9.0
keras==2.7.0
Keras-Preprocessing==1.1.2
pandas==1.3.4
tensorflow==2.7.0
tensorflow-estimator==2.7.0
tensorflow-io-gcs-filesystem==0.23.1
```
The full set (from the output of `pip freeze`) is in `requirements.txt`.  To initially configure an environment, first create and activate a new Python 3.9 virtual environment (see https://docs.python.org/3.9/library/venv.html).  Then, from the top-level folder (the one containing this file), do
```
pip install -r requirements.txt
```

### spaCy Code

The dependent spaCy code respository ([NLP4RE](https://github.gatech.edu/Boeing-NLP4RE/NLP4RE)), must be connected by copying or linking the folder `NLP4RE/spaCy/nlp4re` to `nlp4re` in this top-level folder (i.e. so that `Web-UI/nlp4re` points to or contains the contents of `NLP4RE/spaCy/nlp4re`).

On Linux, assuming both repositories exists side-by-side (in `~/Documents`) a symbolic link could be created with:
```
cd ~/Documents/Web-UI
ln -s ../NLP4RE/spaCY/nlp4re
```
On Windows, a directory junction could be created with:
```
cd %USERPROFILE%\Documents\Web-UI
mklink /J nlp4re ..\NLP4RE\spaCy\nlp4re
```
On either platform, copying `NLP4RE/spaCy/nlp4re` to the top of the `Web-UI` repository folder works as well.

## Execution

The app may be run either locally-- where the python interpreter runs as a process directly in the current OS-- or within Docker.  Note that the port number by which it may be reached differs between the two.

### Direct/Local Mode

To run the UI in a local process, activate a Python 3.9 environment (see above), and run `ui.py`:
```
python ui.py
```
Within 1-2 minutes, the service should be reachable at http://localhost:5000/

### Docker

To run the app within Docker, activate your Python environment, as above, and do:
```
    docker build -t nlp4re-ui .
```
to build the initial image.  Then run that image in a new container with:
```
    docker run -dp 34553:5000 nlp4re-ui
```
Expect startup to take 3-4 times as long as with direct mode, after which the service will be reachable at http://localhost:34553/



