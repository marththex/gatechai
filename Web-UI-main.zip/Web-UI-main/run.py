import numpy as np
import pandas as pd
from imblearn.under_sampling import RandomUnderSampler
from sklearn.model_selection import train_test_split
from keras.preprocessing.text import Tokenizer 
from keras.preprocessing.sequence import pad_sequences
import tensorflow as tf
from keras.models import load_model

maxlen = 100 
embedding_dim = 100
# classes = ['Environmental','Suitability','Design']


def build_model(input_data):
    """Obtain (load or build) the requirements classification model.
    If an existing model and tokenizer can be loaded from the local `models/` folder,
    then these are loaded and returned.  Otherwise, a new model is constructed and
    trained on data in the given file, then saved in the `models/` folder.

    The tokenizer is required as it contains the token indices for the model's vocabulary.
    Since training is a stochastic process, and token indices are assigned in the
    order encountered, they are unique for any given training.  This is why the tokenizer
    is saved alongside the model.

    Note that no checks are currently done on the loaded objects to confirm that they
    match the given data or each other.  If a data varies between runs, manual
    deletion of these files is required.

    Args:
        input_data (str): file path (relative to workspace/cwd) of input CSV data.

    Returns:
        tf.keras.Model: Classification model corresponding to the given input data
        Tokenizer: Tokenizer instance corresponding to the model.
    """
    model : tf.keras.Model
    predictions : np.ndarray

    print("Obtaining classification model...")
    df  = pd.read_csv(input_data)
    y = df['label'] 
    df.drop('label', inplace = True, axis = 1) 
    X_us, y_us = RandomUnderSampler().fit_resample(df,y) 
    X_train, X_test, y_train, y_test = train_test_split(X_us, y_us, stratify = y_us, test_size = 0.25, random_state = 42)
    X_train = X_train.to_numpy()
    X_test = X_test.to_numpy()
    y_train = y_train.to_numpy()
    y_test = y_test.to_numpy()


    try:
        model = load_model('models/model.tf', compile=True)
        print("cached model found")
        tkzr = tf.keras.preprocessing.text.tokenizer_from_json(tf.io.read_file('models/tk.json').numpy())
        print("===== Model and Tokenizer both successfully loaded from files.  Will reuse these. =====")
        model.summary()
        X_test = tkzr.texts_to_sequences(X_test.flatten()) # New words appear since only the training set was tokenized
        X_test = pad_sequences(X_test, padding = "post", maxlen = maxlen)
    except BaseException as be:
        print("Generating classification model")
        tkzr = Tokenizer(num_words = 5000)
        tkzr.fit_on_texts(X_train.ravel())  # Only fit the train data
        X_test = tkzr.texts_to_sequences(X_test.flatten()) # New words appear since only the training set was tokenized
        X_test = pad_sequences(X_test, padding = "post", maxlen = maxlen)
        X_train = tkzr.texts_to_sequences(X_train.flatten())
        X_train = pad_sequences(X_train, padding = "post", maxlen = maxlen)
        vocab_size = len(tkzr.word_index)+1
        model = tf.keras.Sequential([
            tf.keras.layers.Embedding(vocab_size, embedding_dim), 
            tf.keras.layers.Bidirectional(tf.keras.layers.LSTM(embedding_dim)), 
            tf.keras.layers.Dense(embedding_dim, activation = 'relu'), 
            tf.keras.layers.Dense(3, activation = 'softmax')
        ])
        print("model generated")
        model.compile(loss='sparse_categorical_crossentropy', optimizer='adam', metrics=['accuracy'])
        history = model.fit(X_train, y_train, epochs=15, verbose=0, validation_data=(X_test, y_test))
        print("model trained")
        model.save('models/model.tf', overwrite=True, include_optimizer=True, save_traces=True)
        print("model saved")
        tf.io.write_file('models/tk.json', tkzr.to_json())
        print("tokenizer saved")

    predictions = model.predict(X_test)
    print("model tested")
    correct_prediction = 0
    bad_prediction = 0

    num_predictions = len(predictions)
    for i,x in enumerate(predictions): 
        k = x.argmax(axis = 0)
        actual_type = y_test[i]
        if k == actual_type:
            correct_prediction += 1
        else:
            bad_prediction += 1
            print(f'Misprediction {bad_prediction}: req {i}, predClass {k}, actualClass: {actual_type}')
    accuracy = (correct_prediction*1.0) / num_predictions
    print(f'Model accuracy: {accuracy}% (Correct: {correct_prediction} of {num_predictions}, wrong: {bad_prediction})')

    return model, tkzr

def classify(model, tokenizer, sentence):
    X_test = tokenizer.texts_to_sequences(np.array(sentence).flatten())
    X_test = pad_sequences(X_test, padding = "post", maxlen = maxlen)
    probs = model.predict(X_test)[0]
    return probs
