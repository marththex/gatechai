// Dynamic HTML Form-handling Logic

/** Push a selected drop-down value to its partner text input.
 * 
 * @param {*} id Base ID of the parent 'selectable' <div> (containing the 'text_' and 'sel_' inputs).
 * @returns 
 */
function push_val(id) {
    var ctr = document.getElementById(id);
    // if (!ctr.style.display)
    //     return;
    var txtIn = document.getElementById('text_'+id);
    var selIn = document.getElementById('sel_'+id);
    if (!txtIn || !selIn) {
        console.error("One or more essential elements not defined for ID '"+id+"'");
        return;
    }
    txtIn.value = selIn.value;
    ctr.value = selIn.value;

    if (hasClass(ctr, 'required'))
       validate(id);
}

function validate(id) {
    var ctr = document.getElementById(id);
    var txtIn = document.getElementById('text_'+id);
    var selIn = document.getElementById('sel_'+id);
    if (!txtIn || !selIn) {
        console.error("One or more essential elements not defined for ID '"+id+"'");
        return;
    }

    if (ctr.classList.contains('required')) {
        if (!isValid(ctr)) {
            addClass(ctr,'unsat');
            removeClass(ctr,'sat');
        } else {
            addClass(ctr, 'sat');
            removeClass(ctr, 'unsat');
        }
    }
    validate_form();
}

/** Validate required form elements.
 * 
 * @summary
 * Scan all required form elements to see if they have non-empty values set.
 * Add/remove the `unsat` CSS class from elements to reflect their state.
 * 
 * @returns [allSatisfied,anyChanged]
 *  * `allSatisfied` - True if all required element values are non-blank
 *  * `anyChanged` - True if this any state changes were found.
 * 
 */
 function validate_form() {
    var unsat=false, mod=false;     // track existence of unsat or mod'd inputs

    // Scan all required inputs
    for (let re of document.getElementsByClassName("required")) {
        if (re instanceof Element && hasClass(re,'selectable')) {
            if (hasClass(re,'unsat')) {
                unsat = true;
                break;
            }
        }
    }

    // Process token usages (in data attrib of selected <option>)
    // Iterate on
    for (let sel of document.getElementsByTagName("select")) {          // all <select> tags
        var selOpt = sel.options[sel.selectedIndex];
        if (!selOpt)
            continue;
        var tokens = selOpt.getAttribute('data');
        if (!tokens)
            continue;
        for (let token of tokens.split(',')) {
            spn = document.getElementById(token)
            removeClass(spn,'token_unused');
            addClass(spn,'token_used');
        }
    }
    // Scan all BP element containers
    // for (let box of document.getElementsByClassName("bp_elem")) {
    //     if (!box || !box.firstElementChild || !box.lastElementChild)
    //         continue;
    //     first = box.firstElementChild 
    //     last = box.lastElementChild 
    //     if (first.id == 'text_'+box.id && last.id == 'sel_'+box.id && last.value && first.value != last.value) {
    //         first.value = last.value;
    //     }

    //     if (box.classList.contains('required')) {
    //         if (isEmpty(box)) {
    //             addClass(box,'unsat');
    //             removeClass(box,'sat');
    //         } else {
    //             addClass(box, 'sat');
    //             removeClass(box, 'unsat');
    //         }
    //     }
            
        // te = document.getElementById('text_'+se.id)
        // if (te) {
        //     if (te.value=='')
        //         te.value = se.value;
        // }
    // }
    document.getElementById('final').disabled = unsat;
    return [!unsat, mod];
}

function hasClass(e, name) {
    return (e instanceof Element && e.classList.contains(name));
}

/** Add a CSS class name to a form element and its containing div.
 * 
 * Conditionally add the given non-empty name to the given element, if not already
 * present, and the name+'div' to its parent div.
 * 
 * @param {Element} e The DOM element to which the class is to be added.
 * @param {String} name The CSS class name to add.
 * @returns True if one or both additions were performed.
 */
function addClass(e, name) {
    if ( !((e instanceof Element) && name) )
        return false;
    var mod=false;
    if (e instanceof Element && !(e.classList.contains(name))) {
        e.classList.add(name);
        mod=true;
    }
    var ctr = e.parentElement;
    if (ctr instanceof Element && ctr.tagName==='DIV' && !(ctr.classList.contains(name+'_div'))) {
        ctr.classList.add(name+'_div');
        mod=true;
    }
    return mod;
}

/** Remove a CSS class name from a form element and its containing div.
 * 
 * Remove the given non-empty class name from the given DOM element, if already
 * present, and the name+'div' from its parent div.
 * 
 * @param {Element} e The DOM element to which the class is to be removed.
 * @param {String} name The CSS class name to remove.
 * @returns True if one or both removals were performed.
 */
function removeClass(e, name) {
    if ( !((e instanceof Element) && name) )
        return false;
    var mod=false;
    if (e instanceof Element && e.classList.contains(name)) {
        e.classList.remove(name);
        mod=true;
    }
    var ctr = e.parentElement;
    name = name+'_div';
    if (ctr instanceof Element && ctr.tagName==='DIV' && ctr.classList.contains(name)) {
        ctr.classList.remove(name);
        mod=true;
    }
    return mod;
}

/** Indicate whether or not a selectable div has a text component with an empty value.
 * 
 * @param {div} box The selectable (div) element
 */
function isValid(box) {
    if (!box || !document.getElementById('sel_'+box.id) || !document.getElementById('text_'+box.id))
        return false;
    var txtIn = document.getElementById('text_'+box.id).value;
    var sel = document.getElementById('sel_'+box.id);
    var opt = sel.options[sel.selectedIndex];
    var optVal = opt.value;
    var valid = txtIn!='';
    if (opt.getAttribute("data-fit")=="False") {
        if (txtIn==optVal)
            valid = false;
    }
    return valid;
}

var types=['env','suitability','design'];
var active_bp_class='';
var active_bp='';

/**
 * Activate the given category/class of bp/reqs.  Sets
 * 
 * @summary
 * Select the given BP/Req class and show the first template available within it.
 * 
 * @param {number} typeIdx REQUIRED Class index to activate (0:env, 1:sui, 2:des).
 * @param {number} subIdx OPTIONAL Subclass (boilerplate) index to activate, within the class.
 * If omitted, the first boilerplate for the given class is assumed.
 * 
 */
function set_bp(typeIdx, subIdx=0) {        // Set boilerplate (by type only, or type & subtype)
    //if (model_selected !== typeIdx) {       // If clicked class is differs from the current...
        document.getElementById("override_class").value = typeIdx;
        document.getElementById("sub_class").value = subIdx;
        document.getElementById("classifier").submit();
        return;
    //}

    active_bp_class = types[typeIdx];
    active_bp = active_bp_class+'1';
    document.getElementById(active_bp_class+'_container').style.display='block';
    //document.getElementById(active_bp).style.display='block';
    show_template(active_bp);

    return;
    var bpid = 'bp'+typeIdx;
    for (var k=0; k<5; k++) {
        var tgt = document.getElementById('bp'+k);
        if (tgt==null)
            break;
        if (k==typeIdx)
            tgt.style.display = 'block';
        else
            tgt.style.display = 'none';
    }
    // fval(1,50);
}

function show_template(show) {
    for (let h of document.getElementsByClassName("bp")) {
        h.style.display="none"; // ("display:none;");
    }
    document.getElementById(show).style.display="block";
}

function init() {               // Init form
    // set_bp(model_selected);
    document.getElementById("s1").focus();
    for (let re of document.getElementsByClassName("selectable"))
        push_val(re.id);

    //if (document.getElementsByClassName('bp').length > 1)
     //   show_template(document.getElementsByClassName("default_bp")[0].id);
};

