from __future__ import annotations
import sys, os
from os import path, walk
from ast import List
import pandas as pd
from flask import Flask, render_template, send_from_directory, request
from run import build_model, classify
sys.path.append(os.path.abspath("../MW/spaCy")) # merge namespaces-- MUST PRECEDE XXX_Handler imports
from nlp4re.elements.element import Element
from nlp4re.elements.section_resource import SectionResource
from nlp4re.elements.section import Section
from nlp4re.elements.resource import Resource
from nlp4re.elements.boundary_value import BoundaryValue
from nlp4re.elements.boundary import Boundary
from nlp4re.elements.value import Value
from nlp4re.elements.condition_event import Condition_Event
from nlp4re.elements.characteristic import Characteristic
from nlp4re.elements.state import State
from nlp4re.elements.when import When
from nlp4re.elements.agent import Agent
from nlp4re.elements.article_agent import Article, ArticleAgent
from nlp4re.handler.requirement_handler import Requirement_Handler
from nlp4re.handler.environment_handler import Environment_Handler
from nlp4re.handler.suitability_handler import Suitability_Handler
from nlp4re.handler.design_handler import Design_Handler

nlp_data_files = dict(
    env="nlp4re/Env Reqs Manual Conversion - Final - Compare.xlsx",
    sui="nlp4re/suitability_manual.xlsx",
    des="nlp4re/Design Reqs Manual Conversion - Final.xlsx"
)
"""Dict of data file paths for category-specific handlers."""

classes={'Environmental':[0,1],'Suitability':[0],'Design':[0,1,2]}
"""Map of requirement type/category names and corresponding subtype/category indices, as lists.
    This is overspecified on the RHS, which actually only convey the NUMBER of subtypes-- values
    are lists which always count (contiguously) from 0 to some number (N-1).  Thus, `'Type1':[0,1,2]`
    could be reduced to just `'Type1':[3]`.  The current form simplifies its use in code.
"""

cls_short = ['env','sui','des']
"""Ordered list of category keys, short form.
    This is somewhat redundant, but added to provide a reliably-ordered view on the abbreviated
    category names.  Views on the keys of `nlp_data_files` should match this, both in content AND
    order, but the latter is not guaranteed (prior to Python 3.7).  This list addresses that gap.
"""

eh = Environment_Handler()
eh.process_lines_excel({"name":nlp_data_files['env'], "tab":"compare", "column":"Original"})
sh = Suitability_Handler()
sh.process_lines_excel({"name":nlp_data_files['sui'], "tab":"compare", "column":"Original"})
dh = Design_Handler()
dh.process_lines_excel({"name":nlp_data_files['des'], "tab":"Boeing_design_boilerplates", "column":"Requirement Text"})

classify_data = "data/requirement_samples.csv"
handlers = [eh,sh,dh]   # order MUST match cls_short & classes
model, tokenizer = build_model(classify_data)

Flask.jinja_options={'lstrip_blocks': True}
app = Flask(__name__)
# app.jinja_env.add_extension('jinja2.ext.debug')

def load_corpus(file):
    """Load corpus text and classification truth data.
    Input is expected to be 2-column CSV data, labelled (in the first row), 
    'requirement' and 'label'.  Column order can be varied, and additional
    columns may be added.  But these two must exist and containedm, for each
    requirement, its document/text and correct category index, respectively.
    The categories are indexed as
        0. Environmental
        1. Suitability
        2. Design
    The 'requirement' field may be quoted, if it contains the delimiter
    character (comma).  The 'label' must not be, and must be an int literal.

    Args:
        file (str): the input CSV file path, relative to the workspace folder

    Returns:
        List[str]: Requirement text as plain strings
        List[int]: Actual category of each requirement.
    """
    df = pd.read_csv(file)

    try:
        lines = df['requirement'].to_list()
        cats = df['label'].to_list()
    except TypeError as e:
        print(f'ERROR - Failed to parse CSV input: ', e)
        lines = ["File error"]
        cats = [-1]

    return lines, cats


def get_conf(obj: Element):
    """Return a confidence value for each alternative in a BP-element suggestion set.
        Ask each Element for its value, treat strings as exact (Confidence=1.0), and
        anything else results in a TypeError.
    """
    if isinstance(obj,Element):
        return obj.getConfidenceValue()
    elif isinstance(obj,str):
        return 1.0
    else:
        raise TypeError(f"Invalid type in element list:{type(obj)}")
    return 0.0

@app.route('/')
def my_form():
    """Render top portion of main UI form (requirement selection).
    The list of requirements is prepended with a blank entry, which is preselected,
    so that the rest of the regular form (showing classification model result and boilerplate)
    is not shown.

    Returns:
        str: Rendered template of the top-level page, with initial blank entry preselected.
    """
    corpus, cats = load_corpus(classify_data)
    return render_template('base.html.jinja', stage=1, corpus=corpus)


@app.route('/', methods=['POST'])
def my_form_post():
    """Render main template/element selection form.
    This is the main working form using the results of both the classification and
    spaCy models, but allowing the user to override the resulting preselections
    of both.
    
    It is only triggered by a POST request on '/', which means a requirement
    selection for processing has been made.  This can happen in either of TWO ways:
     1. Selection of a requirement in the first <SELECT> - submission of the first
        form, generated by tmpl.selector_form() -- .f1.
     2. User-override selection of a req type prediction - submission of the second
        form, generated by model_output() -- .classifier.
    The classification model determines the type/class `X`, of that selected requirement,
    expressed as a list of probabilities, summing to 1.  It CANNOT, however, determine
    subtype Y (i.e. which boilerplate within the most probable type).  Thus, .f1 will
    always indicate `X.1` (type `X`, subtype `1`).

    User-override CAN indicate both type and subtype, `X.Y`, and

    Returns:
        str: Rendered HTML of the complete main working form.
    """
    corpus, acats = load_corpus(classify_data)
    req_text = request.form['text']
    req_num: int = corpus.index(req_text)+1
    odds = classify(model, tokenizer, req_text)
    favorite: int = odds.argmax(axis=0)
    sub_class = 0
    if 'override_class' in request.form and request.form['override_class']:
        favorite = int(request.form['override_class'])
        if ('sub_class' in request.form):
            sub_class = int(request.form['sub_class'])
    active_bp = f"{cls_short[favorite]}{sub_class+1}"
    hdlr : Requirement_Handler = handlers[favorite]
    hdlr.process_line(req_text,req_num)
    elems = hdlr.getElements()
    edict = {'agent':[], 'article':[], 'articleagent':[], 'boundary':[], 'boundary_value':[], 'characteristic':[],
        'condition_event':[], 'section_resource':[], 'condition':[],'section':[],'event':[],'resource':[], 'value':[],
        'when':['during','after','during and after'],'duration':['at least','greater than']}

    for e in elems:
        elem_name = type(e).__name__.lower()
        if elem_name == 'sectionresource':
            append_element(edict,'section',e._elements[Section])
            append_element(edict,'resource',e._elements[Resource])
        elif elem_name == 'boundary_value':
            append_element(edict,'boundary',e._elements[Boundary])
            append_element(edict,'value',e._elements[Value])
        elif elem_name == 'articleagent':
            append_element(edict,'article',e._elements[Article])
            append_element(edict,'agent',e._elements[Agent])
        else:
            append_element(edict,elem_name,e)


    # Sort lists for BP's, each in desc order of confidence, and store in dict by elem type
    for e_name,choices in edict.items():
        if len(choices) > 0 and isinstance(choices[0], Element):
            edict[e_name] = sorted(choices, key=get_conf, reverse=True)
        
    return render_template('base.html.jinja', stage=2, corpus=corpus,
        req_text=req_text,      # The text of the current requirement statement
        req_num=req_num,        # The number of the current requirement statement
        odds=odds,              # List of probabilities for choosing each class returned by the model
        cat_bps=classes,      # The class/type names ('Environmental','Suitability',...)
        short_nm=cls_short,
        favorite=favorite,      # The model-selected reqt class (0-based index)
        subclass=sub_class,
        elements=edict,         # spaCy model's lists of elements, by name ('agent','boundary',...)
    )


def append_element(edict,elem_name,e):
    """Collate elements by type.  Add the given element, `e`, to the list
    associated with the given element type, `elem_name`, in the global
    dictionary, `edict`.

    Args:
        edict (dict[str,[element]]): BP elements, keyed by BP element type name
        tdict (dict[element,[str]]): To
        elem_name (str): BP element type/name of the given element
        e (element): BP element to be stored.
    """
    if not elem_name in edict:              # Ensure dict has an entry for this element type
        edict[elem_name] = []               #   ... adding and empty list, if not.
    if e:
        edict[elem_name].append(e)          # FIXME: Sample tag to test IDE


@app.route('/record', methods=['POST'])
def record():
    sentence = request.form['sentence']
    user_selection = request.form['choice']
    row = {
        'requirement': [sentence],
        'label':[user_selection]}
    df = pd.DataFrame(row)
    df.to_csv("data/user_choices.csv", mode='a', index=False, header=False)
    return render_template('final.html')


@app.route('/favicon.ico')
def favicon():
    return send_from_directory('static', 'favicon.ico')


if __name__ == '__main__':
   app.run(debug = True, use_debugger=False, use_reloader=False)